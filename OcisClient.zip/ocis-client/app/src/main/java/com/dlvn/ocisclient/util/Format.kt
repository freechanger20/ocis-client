package com.dlvn.ocisclient.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun fmtSize(b: Long): String {
    if (b < 1024) return "$b Б"
    val units = arrayOf("КБ", "МБ", "ГБ", "ТБ")
    var v = b / 1024.0
    var i = 0
    while (v >= 1024 && i < units.size - 1) { v /= 1024; i++ }
    return if (v >= 100) "%.0f %s".format(v, units[i]) else "%.1f %s".format(v, units[i])
}

private val df = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
fun fmtDate(ms: Long): String = if (ms <= 0) "" else df.format(Date(ms))
