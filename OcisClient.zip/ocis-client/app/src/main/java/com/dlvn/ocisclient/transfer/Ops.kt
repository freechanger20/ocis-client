package com.dlvn.ocisclient.transfer

import android.content.Context
import android.net.Uri
import com.dlvn.ocisclient.data.Settings
import com.dlvn.ocisclient.net.HttpError
import com.dlvn.ocisclient.net.RemoteEntry
import com.dlvn.ocisclient.net.WebDav
import com.dlvn.ocisclient.util.Saf
import com.dlvn.ocisclient.util.TarStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody
import okio.BufferedSink
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.coroutines.coroutineContext

private const val BUF = 256 * 1024
private const val SEGMENT_MIN = 8L * 1024 * 1024
private val OCTET: MediaType = "application/octet-stream".toMediaType()

fun joinPath(dir: String, name: String) = (dir.trimEnd('/') + "/" + name).let { if (it.startsWith("/")) it else "/$it" }

/** Тело запроса из потока с учётом прогресса и корректным откатом при повторе. */
private class StreamBody(
    private val length: Long,
    private val onBytes: (Long) -> Unit,
    private val open: () -> InputStream,
) : RequestBody() {
    private var sent = 0L
    override fun contentType() = OCTET
    override fun contentLength() = length
    override fun writeTo(sink: BufferedSink) {
        if (sent > 0) { onBytes(-sent); sent = 0 }
        open().use { inp ->
            val buf = ByteArray(BUF)
            while (true) {
                val n = inp.read(buf)
                if (n < 0) break
                sink.write(buf, 0, n)
                sent += n
                onBytes(n.toLong())
            }
        }
    }
}

private suspend fun <T> retrying(times: Int = 4, block: suspend (attempt: Int) -> T): T {
    var last: Throwable? = null
    for (i in 0 until times) {
        coroutineContext.ensureActive()
        try {
            return block(i)
        } catch (e: HttpError) {
            // 4xx (кроме 408/423/429) повторять бессмысленно
            if (e.code in 400..499 && e.code !in listOf(408, 423, 429)) throw e
            last = e
        } catch (e: IOException) {
            last = e
        }
        delay(1000L * (i + 1))
    }
    throw last ?: IOException("Ошибка передачи")
}

class Ops(private val ctx: Context, private val dav: WebDav, private val s: Settings) {

    // ================= ЗАГРУЗКА В ОБЛАКО =================

    /** Загрузка выбранных файлов в папку облака. */
    suspend fun uploadFiles(t: Task, uris: List<Uri>, remoteDir: String) = withContext(Dispatchers.IO) {
        val items = uris.map { Triple(it, Saf.displayName(ctx, it), Saf.size(ctx, it)) }
        t.filesTotal.set(items.size)
        t.total.set(items.sumOf { maxOf(it.third, 0) })
        t.phase = "Загрузка"
        val sem = Semaphore(s.parallelFiles.coerceIn(1, 8))
        coroutineScope {
            items.map { (uri, name, size) ->
                launch {
                    sem.withPermit {
                        retrying {
                            dav.put(joinPath(remoteDir, name), StreamBody(size, t::add) {
                                ctx.contentResolver.openInputStream(uri) ?: throw IOException("Нет доступа к $name")
                            }, null)
                        }
                        t.filesDone.incrementAndGet()
                    }
                }
            }
        }
    }

    /** Загрузка папки со всей структурой. Файлы, которые уже есть в облаке с тем же размером, пропускаются. */
    suspend fun uploadTree(t: Task, tree: Uri, remoteDir: String) = withContext(Dispatchers.IO) {
        t.phase = "Чтение папки"
        val rootName = Saf.treeName(ctx, tree)
        val items = Saf.walk(ctx, tree)
        val files = items.filter { !it.doc.isDir }
        t.filesTotal.set(files.size)
        t.total.set(files.sumOf { it.doc.size })

        val target = joinPath(remoteDir, rootName)
        t.phase = "Сравнение с облаком"
        val remote = if (dav.stat(target) != null) dav.walk(target) else emptyList()
        val existing: Map<String, Long> = remote.filter { !it.isDir }.associate { it.path to it.size }
        val existingDirs: Set<String> = remote.filter { it.isDir }.map { it.path }.toHashSet()

        t.phase = "Создание папок"
        dav.mkcol(target)
        for (d in items.filter { it.doc.isDir }) {
            coroutineContext.ensureActive()
            val p = joinPath(target, d.rel)
            if (p !in existingDirs) retrying { dav.mkcol(p) }
        }

        t.phase = "Загрузка"
        val sem = Semaphore(s.parallelFiles.coerceIn(1, 8))
        coroutineScope {
            for (f in files) launch {
                sem.withPermit {
                    val p = joinPath(target, f.rel)
                    if (existing[p] == f.doc.size) {
                        t.add(f.doc.size); t.filesSkipped.incrementAndGet()
                    } else {
                        val uri = Saf.docUri(tree, f.doc.docId)
                        retrying {
                            dav.put(p, StreamBody(f.doc.size, t::add) {
                                ctx.contentResolver.openInputStream(uri) ?: throw IOException("Нет доступа к ${f.rel}")
                            }, f.doc.modified)
                        }
                    }
                    t.filesDone.incrementAndGet()
                }
            }
        }
    }

    /** Упаковка папки в ZIP на телефоне и загрузка одного архива. */
    suspend fun uploadTreeAsZip(t: Task, tree: Uri, remoteDir: String) = withContext(Dispatchers.IO) {
        t.phase = "Чтение папки"
        val rootName = Saf.treeName(ctx, tree)
        val items = Saf.walk(ctx, tree)
        val files = items.filter { !it.doc.isDir }
        t.filesTotal.set(files.size)
        t.total.set(files.sumOf { it.doc.size })
        val tmp = File(ctx.externalCacheDir ?: ctx.cacheDir, "upload-${t.id}.zip")
        try {
            t.phase = "Архивация (уровень ${s.zipLevel})"
            ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp), 1 shl 20)).use { zos ->
                zos.setLevel(s.zipLevel.coerceIn(0, 9))
                zos.putNextEntry(ZipEntry("$rootName/")); zos.closeEntry()
                val buf = ByteArray(BUF)
                for (it in items) {
                    coroutineContext.ensureActive()
                    val name = "$rootName/${it.rel}"
                    if (it.doc.isDir) {
                        zos.putNextEntry(ZipEntry("$name/")); zos.closeEntry()
                    } else {
                        val e = ZipEntry(name)
                        if (it.doc.modified > 0) e.time = it.doc.modified
                        zos.putNextEntry(e)
                        ctx.contentResolver.openInputStream(Saf.docUri(tree, it.doc.docId))?.use { inp ->
                            while (true) {
                                val n = inp.read(buf)
                                if (n < 0) break
                                zos.write(buf, 0, n)
                                t.add(n.toLong())
                            }
                        }
                        zos.closeEntry()
                        t.filesDone.incrementAndGet()
                    }
                }
            }
            t.phase = "Загрузка архива"
            val len = tmp.length()
            t.total.set(len); t.done.set(0)
            retrying {
                dav.put(joinPath(remoteDir, "$rootName.zip"), StreamBody(len, t::add) { FileInputStream(tmp) }, null)
            }
        } finally {
            tmp.delete()
        }
    }

    // ================= СКАЧИВАНИЕ =================

    private class RangeUnsupported : IOException("Сервер не поддерживает Range")

    /** Скачивает файл в uri, при большом размере — несколькими потоками. */
    private suspend fun downloadInto(t: Task, remote: String, size: Long, dst: Uri) = coroutineScope {
        val pfd = ctx.contentResolver.openFileDescriptor(dst, "rw") ?: throw IOException("Нет доступа к файлу")
        pfd.use {
            FileOutputStream(it.fileDescriptor).channel.use { ch ->
                ch.truncate(0)
                val fileBytes = java.util.concurrent.atomic.AtomicLong(0)
                fun add(n: Long) { fileBytes.addAndGet(n); t.add(n) }
                suspend fun fetch(a: Long, b: Long, single: Boolean) {
                    var pos = a
                    var fails = 0
                    while (b < 0 || pos <= b) {
                        coroutineContext.ensureActive()
                        try {
                            dav.get(remote, pos, if (single) -1 else b).use { r ->
                                if (r.code == 200 && pos > 0) {
                                    if (!single) throw RangeUnsupported()
                                    add(-(pos - a)); pos = 0   // докачка не поддержана — с начала
                                }
                                val inp = r.body!!.byteStream()
                                val buf = ByteArray(BUF)
                                while (true) {
                                    val n = inp.read(buf)
                                    if (n < 0) break
                                    val bb = ByteBuffer.wrap(buf, 0, n)
                                    var p = pos
                                    while (bb.hasRemaining()) p += ch.write(bb, p)
                                    pos += n
                                    add(n.toLong())
                                }
                            }
                            if (b < 0 || pos > b) return
                            // поток закончился раньше времени — докачиваем с текущей позиции
                            if (++fails > 6) throw IOException("Соединение обрывается")
                            delay(500L * fails)
                        } catch (e: RangeUnsupported) {
                            throw e
                        } catch (e: HttpError) {
                            if (e.code in 400..499 && e.code != 429) throw e
                            if (++fails > 6) throw e
                            delay(1000L * fails)
                        } catch (e: IOException) {
                            if (++fails > 6) throw e
                            delay(1000L * fails)
                        }
                    }
                }

                val seg = s.segments.coerceIn(1, 8)
                if (size < SEGMENT_MIN || seg == 1) {
                    fetch(0, size - 1, single = true)
                } else {
                    val part = (size + seg - 1) / seg
                    try {
                        coroutineScope {
                            (0 until seg).map { i ->
                                val a = i * part
                                val b = minOf(size - 1, a + part - 1)
                                async(Dispatchers.IO) { if (a <= b) fetch(a, b, single = false) }
                            }.awaitAll()
                        }
                    } catch (e: RangeUnsupported) {
                        add(-fileBytes.get())
                        ch.truncate(0)
                        fetch(0, size - 1, single = true)
                    }
                }
            }
        }
    }

    private fun requireTree(): Uri =
        s.downloadTree?.let(Uri::parse) ?: throw IOException("Не выбрана папка для скачивания")

    suspend fun downloadFile(t: Task, e: RemoteEntry) = withContext(Dispatchers.IO) {
        val tree = requireTree()
        t.filesTotal.set(1); t.total.set(e.size); t.phase = "Скачивание"
        val (uri, _) = Saf.createOrGetFile(ctx, tree, Saf.rootId(tree), e.name)
        downloadInto(t, e.path, e.size, uri)
        t.filesDone.incrementAndGet()
    }

    /** Скачивание папки по файлам (параллельно, с пропуском уже скачанных). */
    suspend fun downloadDir(t: Task, e: RemoteEntry) = withContext(Dispatchers.IO) {
        val tree = requireTree()
        t.phase = "Чтение папки в облаке"
        val all = dav.walk(e.path)
        val files = all.filter { !it.isDir }
        t.filesTotal.set(files.size); t.total.set(files.sumOf { it.size })
        val dirs = Saf.DirCache(ctx, tree, Saf.rootId(tree))
        val prefix = e.path.trimEnd('/')
        fun rel(p: String) = e.name + p.removePrefix(prefix)
        t.phase = "Создание папок"
        dirs.dirId(e.name)
        for (d in all.filter { it.isDir }) dirs.dirId(rel(d.path))
        t.phase = "Скачивание"
        val sem = Semaphore(s.parallelFiles.coerceIn(1, 8))
        coroutineScope {
            for (f in files) launch {
                sem.withPermit {
                    val r = rel(f.path)
                    val parent = dirs.dirId(r.substringBeforeLast('/', ""))
                    val (uri, existing) = Saf.createOrGetFile(ctx, tree, parent, f.name)
                    if (existing != null && existing.size == f.size) {
                        t.add(f.size); t.filesSkipped.incrementAndGet()
                    } else {
                        downloadInto(t, f.path, f.size, uri)
                    }
                    t.filesDone.incrementAndGet()
                }
            }
        }
    }

    /**
     * Скачивание папки одним потоком через серверный архиватор.
     * unpack = true — распаковка на лету (tar), иначе сохраняется .zip.
     * Быстрее всего для папок с большим количеством мелких файлов.
     */
    suspend fun downloadArchive(t: Task, e: RemoteEntry, unpack: Boolean) = withContext(Dispatchers.IO) {
        val tree = requireTree()
        val id = e.fileId ?: throw IOException("Сервер не вернул id папки")
        t.phase = "Подготовка"
        // размер для прогресса
        t.total.set(if (e.size > 0) e.size else dav.walk(e.path).filter { !it.isDir }.sumOf { it.size })
        if (!unpack) {
            t.filesTotal.set(1)
            val (uri, _) = Saf.createOrGetFile(ctx, tree, Saf.rootId(tree), "${e.name}.zip")
            dav.archive(id, "zip").use { r ->
                t.phase = "Скачивание архива"
                ctx.contentResolver.openOutputStream(uri, "wt")!!.use { out ->
                    val inp = r.body!!.byteStream()
                    val buf = ByteArray(BUF)
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n); t.add(n.toLong())
                    }
                }
            }
            t.filesDone.set(1)
            return@withContext
        }
        val dirs = Saf.DirCache(ctx, tree, Saf.rootId(tree))
        dav.archive(id, "tar").use { r ->
            t.phase = "Скачивание и распаковка"
            val tar = TarStream(r.body!!.byteStream().buffered(1 shl 20))
            val buf = ByteArray(BUF)
            while (true) {
                coroutineContext.ensureActive()
                val en = tar.next() ?: break
                val name = en.name.trimStart('/')
                if (name.isEmpty() || name.split('/').any { it == ".." }) continue
                if (en.isDir) { dirs.dirId(name); continue }
                t.filesTotal.incrementAndGet()
                val parent = dirs.dirId(name.substringBeforeLast('/', ""))
                val (uri, _) = Saf.createOrGetFile(ctx, tree, parent, name.substringAfterLast('/'))
                ctx.contentResolver.openOutputStream(uri, "wt")!!.use { out ->
                    while (true) {
                        val n = tar.entryStream.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n); t.add(n.toLong())
                    }
                }
                t.filesDone.incrementAndGet()
            }
        }
    }
}
