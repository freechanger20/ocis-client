package com.dlvn.ocisclient.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

enum class Screen { BROWSER, TRANSFERS, SETTINGS }

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private var openTransfers = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        openTransfers.value = intent?.getBooleanExtra("openTransfers", false) == true
        setContent {
            AppTheme { Root() }
        }
        if (vm.prefs.account.value != null) vm.refresh()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("openTransfers", false)) openTransfers.value = true
    }

    @Composable
    private fun Root() {
        val account by vm.prefs.account.collectAsState()
        var screen by remember { mutableStateOf(Screen.BROWSER) }
        val wantTransfers = openTransfers.value
        androidx.compose.runtime.LaunchedEffect(wantTransfers) {
            if (wantTransfers) { screen = Screen.TRANSFERS; openTransfers.value = false }
        }

        val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

        // Выбор файлов для загрузки
        val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) vm.uploadFiles(uris)
        }
        // Выбор папки для загрузки (обычной или в ZIP)
        var treeAsZip by remember { mutableStateOf(false) }
        val pickUploadTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                persist(uri, write = false)
                vm.uploadTree(uri, treeAsZip)
            }
        }
        // Папка на телефоне, куда скачивать
        val pickDownloadTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                persist(uri, write = true)
                vm.setDownloadTree(uri)
                vm.runPending()
            } else vm.pending = null
        }

        fun askNotif() {
            if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val actions = BrowserActions(
            uploadFiles = { askNotif(); pickFiles.launch(arrayOf("*/*")) },
            uploadFolder = { zip -> askNotif(); treeAsZip = zip; pickUploadTree.launch(null) },
            download = { p ->
                askNotif()
                vm.pending = p
                if (vm.hasDownloadTree()) vm.runPending() else pickDownloadTree.launch(null)
            },
            chooseDownloadFolder = { pickDownloadTree.launch(null) },
            openTransfers = { screen = Screen.TRANSFERS },
            openSettings = { screen = Screen.SETTINGS },
        )

        if (account == null) {
            LoginScreen(vm)
            return
        }
        when (screen) {
            Screen.BROWSER -> BrowserScreen(vm, actions)
            Screen.TRANSFERS -> {
                BackHandler { screen = Screen.BROWSER }
                TransfersScreen(vm) { screen = Screen.BROWSER }
            }
            Screen.SETTINGS -> {
                BackHandler { screen = Screen.BROWSER }
                SettingsScreen(vm, onPickFolder = { pickDownloadTree.launch(null) }) { screen = Screen.BROWSER }
            }
        }
    }

    private fun persist(uri: Uri, write: Boolean) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
            (if (write) Intent.FLAG_GRANT_WRITE_URI_PERMISSION else 0)
        try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) {}
    }
}

class BrowserActions(
    val uploadFiles: () -> Unit,
    val uploadFolder: (zip: Boolean) -> Unit,
    val download: (Pending) -> Unit,
    val chooseDownloadFolder: () -> Unit,
    val openTransfers: () -> Unit,
    val openSettings: () -> Unit,
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF8AB4F8), secondary = Color(0xFF9CCBFF),
    ) else lightColorScheme(
        primary = Color(0xFF1E5AA8), secondary = Color(0xFF2B6CB0),
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
