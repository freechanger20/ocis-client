package com.dlvn.ocisclient.util

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap

/** Быстрая работа с Storage Access Framework через прямые запросы к провайдеру. */
object Saf {

    data class Doc(
        val docId: String,
        val name: String,
        val isDir: Boolean,
        val size: Long,
        val modified: Long,
    )

    /** Файл или папка внутри выбранного дерева с путём относительно его корня. */
    data class Item(val rel: String, val doc: Doc)

    private val COLS = arrayOf(
        Document.COLUMN_DOCUMENT_ID,
        Document.COLUMN_DISPLAY_NAME,
        Document.COLUMN_MIME_TYPE,
        Document.COLUMN_SIZE,
        Document.COLUMN_LAST_MODIFIED,
    )

    fun rootId(tree: Uri): String = DocumentsContract.getTreeDocumentId(tree)

    fun docUri(tree: Uri, docId: String): Uri = DocumentsContract.buildDocumentUriUsingTree(tree, docId)

    fun children(ctx: Context, tree: Uri, parentId: String): List<Doc> {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val out = ArrayList<Doc>()
        ctx.contentResolver.query(uri, COLS, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                out += Doc(
                    docId = c.getString(0),
                    name = c.getString(1) ?: "?",
                    isDir = c.getString(2) == Document.MIME_TYPE_DIR,
                    size = if (c.isNull(3)) 0 else c.getLong(3),
                    modified = if (c.isNull(4)) 0 else c.getLong(4),
                )
            }
        }
        return out
    }

    fun stat(ctx: Context, tree: Uri, docId: String): Doc? {
        ctx.contentResolver.query(docUri(tree, docId), COLS, null, null, null)?.use { c ->
            if (c.moveToFirst()) return Doc(
                c.getString(0), c.getString(1) ?: "?",
                c.getString(2) == Document.MIME_TYPE_DIR,
                if (c.isNull(3)) 0 else c.getLong(3),
                if (c.isNull(4)) 0 else c.getLong(4),
            )
        }
        return null
    }

    /** Все файлы и папки дерева (папки идут раньше своего содержимого). */
    fun walk(ctx: Context, tree: Uri, docId: String = rootId(tree), prefix: String = ""): List<Item> {
        val out = ArrayList<Item>()
        fun rec(id: String, pre: String) {
            for (d in children(ctx, tree, id)) {
                val rel = if (pre.isEmpty()) d.name else "$pre/${d.name}"
                out += Item(rel, d)
                if (d.isDir) rec(d.docId, rel)
            }
        }
        rec(docId, prefix)
        return out
    }

    fun findChild(ctx: Context, tree: Uri, parentId: String, name: String): Doc? =
        children(ctx, tree, parentId).firstOrNull { it.name == name }

    /** Находит или создаёт подпапку, возвращает её docId. */
    fun ensureDir(ctx: Context, tree: Uri, parentId: String, name: String): String {
        findChild(ctx, tree, parentId, name)?.let { if (it.isDir) return it.docId }
        val created = DocumentsContract.createDocument(
            ctx.contentResolver, docUri(tree, parentId), Document.MIME_TYPE_DIR, name
        ) ?: throw IllegalStateException("Не удалось создать папку $name")
        return DocumentsContract.getDocumentId(created)
    }

    /** Создаёт путь из подпапок (a/b/c) с кешем уже созданных. */
    class DirCache(private val ctx: Context, private val tree: Uri, private val rootId: String) {
        private val map = HashMap<String, String>()
        @Synchronized
        fun dirId(rel: String): String {
            if (rel.isEmpty()) return rootId
            map[rel]?.let { return it }
            val parent = rel.substringBeforeLast('/', "")
            val name = rel.substringAfterLast('/')
            val id = ensureDir(ctx, tree, dirId(parent), name)
            map[rel] = id
            return id
        }
    }

    fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    /** Создаёт новый файл. Если файл с таким именем уже есть — возвращает его. */
    fun createOrGetFile(ctx: Context, tree: Uri, parentId: String, name: String): Pair<Uri, Doc?> {
        val existing = findChild(ctx, tree, parentId, name)
        if (existing != null && !existing.isDir) return docUri(tree, existing.docId) to existing
        val uri = DocumentsContract.createDocument(
            ctx.contentResolver, docUri(tree, parentId), "application/octet-stream", name
        ) ?: throw IllegalStateException("Не удалось создать файл $name")
        return uri to null
    }

    fun displayName(ctx: Context, uri: Uri): String {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst() && !it.isNull(0)) return it.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "file"
    }

    fun size(ctx: Context, uri: Uri): Long {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
            if (it.moveToFirst() && !it.isNull(0)) return it.getLong(0)
        }
        return -1
    }

    fun treeName(ctx: Context, tree: Uri): String =
        stat(ctx, tree, rootId(tree))?.name ?: "Папка"
}
