package com.dlvn.ocisclient.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.ViewHeadline
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import com.dlvn.ocisclient.data.Settings
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvn.ocisclient.net.RemoteEntry
import com.dlvn.ocisclient.transfer.TState
import com.dlvn.ocisclient.util.fmtDate
import com.dlvn.ocisclient.util.fmtSize

private sealed interface Dlg {
    data object NewFolder : Dlg
    data class Rename(val e: RemoteEntry) : Dlg
    data class Delete(val list: List<RemoteEntry>) : Dlg
    data class Move(val list: List<RemoteEntry>) : Dlg
    data class FolderColor(val e: RemoteEntry) : Dlg
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun BrowserScreen(vm: MainViewModel, act: BrowserActions) {
    val path by vm.path.collectAsState()
    val entries by vm.entries.collectAsState()
    val loading by vm.loading.collectAsState()
    val msg by vm.message.collectAsState()
    val sort by vm.sort.collectAsState()
    val filter by vm.filter.collectAsState()
    val tasks by vm.transfers.ui.collectAsState()
    val st by vm.prefs.settings.collectAsState()
    val folderColors by vm.prefs.folderColors.collectAsState()
    val activeCount = tasks.count { it.state == TState.RUNNING || it.state == TState.QUEUED }

    val selected = remember { mutableStateListOf<String>() }
    var dialog by remember { mutableStateOf<Dlg?>(null) }
    var searching by remember { mutableStateOf(false) }
    var fabMenu by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(path) { selected.clear(); searching = false }
    LaunchedEffect(msg) { msg?.let { snackbar.showSnackbar(it); vm.consumeMessage() } }
    BackHandler(enabled = selected.isNotEmpty() || searching || path != "/") {
        when {
            selected.isNotEmpty() -> selected.clear()
            searching -> { searching = false; vm.setFilter("") }
            else -> vm.up()
        }
    }

    val list = remember(entries, sort, filter) {
        val f = filter.trim().lowercase()
        val base = if (f.isEmpty()) entries else entries.filter { it.name.lowercase().contains(f) }
        val cmp: Comparator<RemoteEntry> = when (sort) {
            SortMode.NAME -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }
            SortMode.DATE -> compareByDescending { it.modified }
            SortMode.SIZE -> compareByDescending { it.size }
        }
        base.sortedWith(compareBy<RemoteEntry> { !it.isDir }.then(cmp))
    }
    val selEntries = list.filter { it.path in selected }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            if (selected.isNotEmpty()) {
                TopAppBar(
                    title = { Text("Выбрано: ${selected.size}") },
                    navigationIcon = { IconButton({ selected.clear() }) { Icon(Icons.Filled.Close, "Отмена") } },
                    actions = {
                        IconButton({ selected.clear(); selected.addAll(list.map { it.path }) }) {
                            Icon(Icons.Filled.SelectAll, "Выбрать все")
                        }
                        IconButton({
                            act.download(Pending.Many(selEntries.map { if (it.isDir) Pending.Dir(it) else Pending.File(it) }))
                            selected.clear()
                        }) { Icon(Icons.Filled.Download, "Скачать") }
                        IconButton({ dialog = Dlg.Move(selEntries) }) { Icon(Icons.Filled.DriveFileMove, "Переместить") }
                        IconButton({ dialog = Dlg.Delete(selEntries) }) { Icon(Icons.Filled.Delete, "Удалить") }
                    }
                )
            } else {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                if (path == "/") "Мои файлы" else path.trimEnd('/').substringAfterLast('/'),
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            if (path != "/") Text(
                                path, style = MaterialTheme.typography.labelSmall,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        if (path != "/") IconButton({ vm.up() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") }
                    },
                    actions = {
                        IconButton({ vm.saveSettings(st.copy(viewMode = (st.viewMode + 1) % 3)) }) {
                            Icon(
                                when (st.viewMode) {
                                    0 -> Icons.Filled.ViewHeadline
                                    1 -> Icons.Filled.GridView
                                    else -> Icons.AutoMirrored.Filled.ViewList
                                },
                                "Вид: ${VIEW_MODES[(st.viewMode + 1) % 3]}"
                            )
                        }
                        IconButton({ searching = !searching; if (!searching) vm.setFilter("") }) {
                            Icon(Icons.Filled.Search, "Поиск")
                        }
                        Box {
                            IconButton({ sortMenu = true }) { Icon(Icons.AutoMirrored.Filled.Sort, "Сортировка") }
                            DropdownMenu(sortMenu, { sortMenu = false }) {
                                listOf(SortMode.NAME to "По имени", SortMode.DATE to "По дате", SortMode.SIZE to "По размеру")
                                    .forEach { (m, t) ->
                                        DropdownMenuItem(
                                            text = { Text(t) },
                                            onClick = { vm.setSort(m); sortMenu = false },
                                            trailingIcon = { if (m == sort) Icon(Icons.Filled.CheckCircle, null) }
                                        )
                                    }
                            }
                        }
                        IconButton(act.openTransfers) {
                            BadgedBox(badge = { if (activeCount > 0) Badge { Text("$activeCount") } }) {
                                Icon(Icons.Filled.SwapVert, "Передачи")
                            }
                        }
                        Box {
                            IconButton({ moreMenu = true }) { Icon(Icons.Filled.MoreVert, "Ещё") }
                            DropdownMenu(moreMenu, { moreMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Настройки") },
                                    leadingIcon = { Icon(Icons.Filled.Settings, null) },
                                    onClick = { moreMenu = false; act.openSettings() })
                            }
                        }
                    }
                )
            }
        },
        floatingActionButton = {
            Box {
                FloatingActionButton({ fabMenu = true }) { Icon(Icons.Filled.Add, "Добавить") }
                DropdownMenu(fabMenu, { fabMenu = false }) {
                    DropdownMenuItem(text = { Text("Загрузить файлы") },
                        leadingIcon = { Icon(Icons.Filled.UploadFile, null) },
                        onClick = { fabMenu = false; act.uploadFiles() })
                    DropdownMenuItem(text = { Text("Загрузить папку") },
                        leadingIcon = { Icon(Icons.Filled.Upload, null) },
                        onClick = { fabMenu = false; act.uploadFolder(false) })
                    DropdownMenuItem(text = { Text("Загрузить папку в ZIP") },
                        leadingIcon = { Icon(Icons.Filled.FolderZip, null) },
                        onClick = { fabMenu = false; act.uploadFolder(true) })
                    HorizontalDivider()
                    DropdownMenuItem(text = { Text("Новая папка") },
                        leadingIcon = { Icon(Icons.Filled.CreateNewFolder, null) },
                        onClick = { fabMenu = false; dialog = Dlg.NewFolder })
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (searching) {
                OutlinedTextField(
                    filter, vm::setFilter, singleLine = true,
                    placeholder = { Text("Поиск в этой папке") },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }
            PullToRefreshBox(isRefreshing = loading, onRefresh = { vm.refresh() }, modifier = Modifier.fillMaxSize()) {
                val onClick: (RemoteEntry) -> Unit = { e ->
                    if (selected.isNotEmpty()) {
                        if (e.path in selected) selected.remove(e.path) else selected.add(e.path)
                    } else if (e.isDir) vm.open(e.path)
                    else act.download(Pending.File(e))
                }
                val onLong: (RemoteEntry) -> Unit = { e ->
                    if (e.path in selected) selected.remove(e.path) else selected.add(e.path)
                }
                val menu: @Composable (RemoteEntry, () -> Unit) -> Unit = { e, close ->
                    EntryMenu(e, close, act) { dialog = it }
                }
                val empty = list.isEmpty() && !loading
                if (st.viewMode == 2) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(st.gridColumns.coerceIn(2, 6)),
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(8.dp),
                        verticalArrangement = Arrangement.spacedBy((st.rowSpacing / 2).dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        if (empty) item(span = { GridItemSpan(maxLineSpan) }) { EmptyText(filter) }
                        items(list, key = { it.path }) { e ->
                            EntryTile(e, e.path in selected, st, folderColors[e.path], { onClick(e) }, { onLong(e) }) { close ->
                                menu(e, close)
                            }
                        }
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        if (empty) item { EmptyText(filter) }
                        items(list, key = { it.path }) { e ->
                            EntryRow(e, e.path in selected, st, folderColors[e.path], compact = st.viewMode == 1,
                                onClick = { onClick(e) }, onLongClick = { onLong(e) }) { close -> menu(e, close) }
                            if (st.dividers) HorizontalDivider(Modifier.padding(start = (st.iconSize + 30).dp))
                        }
                    }
                }
            }
        }
    }

    when (val d = dialog) {
        null -> {}
        Dlg.NewFolder -> TextDialog("Новая папка", "", "Создать", { dialog = null }) { vm.mkdir(it) }
        is Dlg.Rename -> TextDialog("Переименовать", d.e.name, "Сохранить", { dialog = null }) { vm.rename(d.e, it) }
        is Dlg.Move -> TextDialog(
            "Переместить ${d.list.size} шт. в папку", path, "Переместить", { dialog = null }
        ) { vm.moveTo(d.list, it); selected.clear() }
        is Dlg.FolderColor -> ColorDialog(folderColors[d.e.path], { dialog = null }) {
            vm.prefs.setFolderColor(d.e.path, it)
        }
        is Dlg.Delete -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Удалить ${d.list.size} шт.?") },
            text = { Text(d.list.take(5).joinToString("\n") { it.name } + if (d.list.size > 5) "\n…" else "") },
            confirmButton = {
                TextButton({ vm.delete(d.list); selected.clear(); dialog = null }) { Text("Удалить") }
            },
            dismissButton = { TextButton({ dialog = null }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun EmptyText(filter: String) {
    Text(
        if (filter.isBlank()) "Папка пуста" else "Ничего не найдено",
        Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun EntryMenu(e: RemoteEntry, close: () -> Unit, act: BrowserActions, setDialog: (Dlg) -> Unit) {
    if (e.isDir) {
        DropdownMenuItem(text = { Text("Скачать папку") },
            onClick = { close(); act.download(Pending.Dir(e)) })
        DropdownMenuItem(
            text = {
                Column {
                    Text("Скачать одним потоком")
                    Text("быстро для множества мелких файлов", style = MaterialTheme.typography.labelSmall)
                }
            },
            onClick = { close(); act.download(Pending.Archive(e, unpack = true)) })
        DropdownMenuItem(text = { Text("Скачать как ZIP") },
            onClick = { close(); act.download(Pending.Archive(e, unpack = false)) })
    } else {
        DropdownMenuItem(text = { Text("Скачать") }, onClick = { close(); act.download(Pending.File(e)) })
    }
    HorizontalDivider()
    if (e.isDir) DropdownMenuItem(text = { Text("Цвет папки") }, onClick = { close(); setDialog(Dlg.FolderColor(e)) })
    DropdownMenuItem(text = { Text("Переименовать") }, onClick = { close(); setDialog(Dlg.Rename(e)) })
    DropdownMenuItem(text = { Text("Переместить") }, onClick = { close(); setDialog(Dlg.Move(listOf(e))) })
    DropdownMenuItem(text = { Text("Удалить") }, onClick = { close(); setDialog(Dlg.Delete(listOf(e))) })
}

@Composable
private fun tintFor(e: RemoteEntry, kind: FileKind, st: Settings, folderColor: Int?, selected: Boolean): Color = when {
    selected -> MaterialTheme.colorScheme.primary
    kind == FileKind.FOLDER -> paletteColor(folderColor ?: st.folderColor)
    st.coloredIcons -> kind.color
    else -> MaterialTheme.colorScheme.onSurfaceVariant
}

private fun details(e: RemoteEntry) =
    listOf(fmtSize(e.size), fmtDate(e.modified)).filter { it.isNotEmpty() }.joinToString(" · ")

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun EntryRow(
    e: RemoteEntry,
    selected: Boolean,
    st: Settings,
    folderColor: Int?,
    compact: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    menu: @Composable (close: () -> Unit) -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    val kind = kindOf(e.name, e.isDir)
    val iconSize = if (compact) (st.iconSize * 0.7f).dp else st.iconSize.dp
    val vPad = if (compact) (st.rowSpacing / 2).dp else st.rowSpacing.dp
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (selected) Modifier.background(MaterialTheme.colorScheme.secondaryContainer) else Modifier)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(start = 16.dp, top = vPad, bottom = vPad, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (selected) checkIcon(st.iconStyle) else iconFor(kind, st.iconStyle),
            null, Modifier.size(iconSize), tint = tintFor(e, kind, st, folderColor, selected)
        )
        if (compact) {
            Text(e.name, Modifier.weight(1f).padding(horizontal = 12.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (st.showDetails && !e.isDir) Text(
                fmtSize(e.size), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(e.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (st.showDetails) Text(
                    details(e), style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Box {
            IconButton({ open = true }) { Icon(Icons.Filled.MoreVert, "Действия") }
            DropdownMenu(open, { open = false }) { menu { open = false } }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun EntryTile(
    e: RemoteEntry,
    selected: Boolean,
    st: Settings,
    folderColor: Int?,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    menu: @Composable (close: () -> Unit) -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    val kind = kindOf(e.name, e.isDir)
    Box(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (selected) MaterialTheme.colorScheme.secondaryContainer
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
            )
            .combinedClickable(onClick = onClick, onLongClick = { open = true })
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = (st.rowSpacing / 2 + 6).dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(
                if (selected) checkIcon(st.iconStyle) else iconFor(kind, st.iconStyle),
                null, Modifier.size((st.iconSize * 1.5f).dp), tint = tintFor(e, kind, st, folderColor, selected)
            )
            Text(
                e.name, maxLines = 2, overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp)
            )
            if (st.showDetails && !e.isDir) Text(
                fmtSize(e.size), style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem(text = { Text(if (selected) "Снять выбор" else "Выбрать") },
                onClick = { open = false; onLongClick() })
            menu { open = false }
        }
    }
}

@Composable
private fun ColorDialog(current: Int?, onDismiss: () -> Unit, onPick: (Int?) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Цвет папки") },
        text = {
            Column {
                PALETTE.chunked(5).forEachIndexed { row, chunk ->
                    Row(Modifier.padding(vertical = 6.dp)) {
                        chunk.forEachIndexed { col, (_, c) ->
                            val idx = row * 5 + col
                            Box(
                                Modifier
                                    .padding(horizontal = 6.dp)
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(c)
                                    .clickable { onPick(idx); onDismiss() },
                                contentAlignment = Alignment.Center
                            ) {
                                if (idx == current) Icon(Icons.Filled.Check, null, tint = Color.White)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton({ onPick(null); onDismiss() }) { Text("По умолчанию") } },
        dismissButton = { TextButton(onDismiss) { Text("Отмена") } }
    )
}

@Composable
fun TextDialog(title: String, initial: String, ok: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true) },
        confirmButton = {
            TextButton({ if (text.isNotBlank()) { onOk(text.trim()); onDismiss() } }) { Text(ok) }
        },
        dismissButton = { TextButton(onDismiss) { Text("Отмена") } }
    )
}
