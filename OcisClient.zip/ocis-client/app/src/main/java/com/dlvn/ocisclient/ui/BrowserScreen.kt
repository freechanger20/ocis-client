package com.dlvn.ocisclient.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvn.ocisclient.net.RemoteEntry
import com.dlvn.ocisclient.transfer.TState
import com.dlvn.ocisclient.util.fmtDate
import com.dlvn.ocisclient.util.fmtSize

private sealed interface Dlg {
    data object NewFolder : Dlg
    data class Rename(val e: RemoteEntry) : Dlg
    data class Delete(val list: List<RemoteEntry>) : Dlg
    data class Move(val list: List<RemoteEntry>) : Dlg
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun BrowserScreen(vm: MainViewModel, act: BrowserActions) {
    val path by vm.path.collectAsState()
    val entries by vm.entries.collectAsState()
    val loading by vm.loading.collectAsState()
    val msg by vm.message.collectAsState()
    val sort by vm.sort.collectAsState()
    val filter by vm.filter.collectAsState()
    val tasks by vm.transfers.ui.collectAsState()
    val activeCount = tasks.count { it.state == TState.RUNNING || it.state == TState.QUEUED }

    val selected = remember { mutableStateListOf<String>() }
    var dialog by remember { mutableStateOf<Dlg?>(null) }
    var searching by remember { mutableStateOf(false) }
    var fabMenu by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(path) { selected.clear(); searching = false }
    LaunchedEffect(msg) { msg?.let { snackbar.showSnackbar(it); vm.consumeMessage() } }
    BackHandler(enabled = selected.isNotEmpty() || searching || path != "/") {
        when {
            selected.isNotEmpty() -> selected.clear()
            searching -> { searching = false; vm.setFilter("") }
            else -> vm.up()
        }
    }

    val list = remember(entries, sort, filter) {
        val f = filter.trim().lowercase()
        val base = if (f.isEmpty()) entries else entries.filter { it.name.lowercase().contains(f) }
        val cmp: Comparator<RemoteEntry> = when (sort) {
            SortMode.NAME -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }
            SortMode.DATE -> compareByDescending { it.modified }
            SortMode.SIZE -> compareByDescending { it.size }
        }
        base.sortedWith(compareBy<RemoteEntry> { !it.isDir }.then(cmp))
    }
    val selEntries = list.filter { it.path in selected }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            if (selected.isNotEmpty()) {
                TopAppBar(
                    title = { Text("Выбрано: ${selected.size}") },
                    navigationIcon = { IconButton({ selected.clear() }) { Icon(Icons.Filled.Close, "Отмена") } },
                    actions = {
                        IconButton({ selected.clear(); selected.addAll(list.map { it.path }) }) {
                            Icon(Icons.Filled.SelectAll, "Выбрать все")
                        }
                        IconButton({
                            act.download(Pending.Many(selEntries.map { if (it.isDir) Pending.Dir(it) else Pending.File(it) }))
                            selected.clear()
                        }) { Icon(Icons.Filled.Download, "Скачать") }
                        IconButton({ dialog = Dlg.Move(selEntries) }) { Icon(Icons.Filled.DriveFileMove, "Переместить") }
                        IconButton({ dialog = Dlg.Delete(selEntries) }) { Icon(Icons.Filled.Delete, "Удалить") }
                    }
                )
            } else {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                if (path == "/") "Мои файлы" else path.trimEnd('/').substringAfterLast('/'),
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            if (path != "/") Text(
                                path, style = MaterialTheme.typography.labelSmall,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        if (path != "/") IconButton({ vm.up() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") }
                    },
                    actions = {
                        IconButton({ searching = !searching; if (!searching) vm.setFilter("") }) {
                            Icon(Icons.Filled.Search, "Поиск")
                        }
                        Box {
                            IconButton({ sortMenu = true }) { Icon(Icons.AutoMirrored.Filled.Sort, "Сортировка") }
                            DropdownMenu(sortMenu, { sortMenu = false }) {
                                listOf(SortMode.NAME to "По имени", SortMode.DATE to "По дате", SortMode.SIZE to "По размеру")
                                    .forEach { (m, t) ->
                                        DropdownMenuItem(
                                            text = { Text(t) },
                                            onClick = { vm.setSort(m); sortMenu = false },
                                            trailingIcon = { if (m == sort) Icon(Icons.Filled.CheckCircle, null) }
                                        )
                                    }
                            }
                        }
                        IconButton(act.openTransfers) {
                            BadgedBox(badge = { if (activeCount > 0) Badge { Text("$activeCount") } }) {
                                Icon(Icons.Filled.SwapVert, "Передачи")
                            }
                        }
                        Box {
                            IconButton({ moreMenu = true }) { Icon(Icons.Filled.MoreVert, "Ещё") }
                            DropdownMenu(moreMenu, { moreMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Настройки") },
                                    leadingIcon = { Icon(Icons.Filled.Settings, null) },
                                    onClick = { moreMenu = false; act.openSettings() })
                            }
                        }
                    }
                )
            }
        },
        floatingActionButton = {
            Box {
                FloatingActionButton({ fabMenu = true }) { Icon(Icons.Filled.Add, "Добавить") }
                DropdownMenu(fabMenu, { fabMenu = false }) {
                    DropdownMenuItem(text = { Text("Загрузить файлы") },
                        leadingIcon = { Icon(Icons.Filled.UploadFile, null) },
                        onClick = { fabMenu = false; act.uploadFiles() })
                    DropdownMenuItem(text = { Text("Загрузить папку") },
                        leadingIcon = { Icon(Icons.Filled.Upload, null) },
                        onClick = { fabMenu = false; act.uploadFolder(false) })
                    DropdownMenuItem(text = { Text("Загрузить папку в ZIP") },
                        leadingIcon = { Icon(Icons.Filled.FolderZip, null) },
                        onClick = { fabMenu = false; act.uploadFolder(true) })
                    HorizontalDivider()
                    DropdownMenuItem(text = { Text("Новая папка") },
                        leadingIcon = { Icon(Icons.Filled.CreateNewFolder, null) },
                        onClick = { fabMenu = false; dialog = Dlg.NewFolder })
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (searching) {
                OutlinedTextField(
                    filter, vm::setFilter, singleLine = true,
                    placeholder = { Text("Поиск в этой папке") },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }
            PullToRefreshBox(isRefreshing = loading, onRefresh = { vm.refresh() }, modifier = Modifier.fillMaxSize()) {
                LazyColumn(Modifier.fillMaxSize()) {
                    if (list.isEmpty() && !loading) item {
                        Text(
                            if (filter.isBlank()) "Папка пуста" else "Ничего не найдено",
                            Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    items(list, key = { it.path }) { e ->
                        EntryRow(
                            e = e,
                            selected = e.path in selected,
                            onClick = {
                                if (selected.isNotEmpty()) {
                                    if (e.path in selected) selected.remove(e.path) else selected.add(e.path)
                                } else if (e.isDir) vm.open(e.path)
                                else act.download(Pending.File(e))
                            },
                            onLongClick = {
                                if (e.path in selected) selected.remove(e.path) else selected.add(e.path)
                            },
                            menu = { close ->
                                if (e.isDir) {
                                    DropdownMenuItem(text = { Text("Скачать папку") },
                                        onClick = { close(); act.download(Pending.Dir(e)) })
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text("Скачать одним потоком")
                                                Text("быстро для множества мелких файлов",
                                                    style = MaterialTheme.typography.labelSmall)
                                            }
                                        },
                                        onClick = { close(); act.download(Pending.Archive(e, unpack = true)) })
                                    DropdownMenuItem(text = { Text("Скачать как ZIP") },
                                        onClick = { close(); act.download(Pending.Archive(e, unpack = false)) })
                                } else {
                                    DropdownMenuItem(text = { Text("Скачать") },
                                        onClick = { close(); act.download(Pending.File(e)) })
                                }
                                HorizontalDivider()
                                DropdownMenuItem(text = { Text("Переименовать") },
                                    onClick = { close(); dialog = Dlg.Rename(e) })
                                DropdownMenuItem(text = { Text("Переместить") },
                                    onClick = { close(); dialog = Dlg.Move(listOf(e)) })
                                DropdownMenuItem(text = { Text("Удалить") },
                                    onClick = { close(); dialog = Dlg.Delete(listOf(e)) })
                            }
                        )
                    }
                }
            }
        }
    }

    when (val d = dialog) {
        null -> {}
        Dlg.NewFolder -> TextDialog("Новая папка", "", "Создать", { dialog = null }) { vm.mkdir(it) }
        is Dlg.Rename -> TextDialog("Переименовать", d.e.name, "Сохранить", { dialog = null }) { vm.rename(d.e, it) }
        is Dlg.Move -> TextDialog(
            "Переместить ${d.list.size} шт. в папку", path, "Переместить", { dialog = null }
        ) { vm.moveTo(d.list, it); selected.clear() }
        is Dlg.Delete -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Удалить ${d.list.size} шт.?") },
            text = { Text(d.list.take(5).joinToString("\n") { it.name } + if (d.list.size > 5) "\n…" else "") },
            confirmButton = {
                TextButton({ vm.delete(d.list); selected.clear(); dialog = null }) { Text("Удалить") }
            },
            dismissButton = { TextButton({ dialog = null }) { Text("Отмена") } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun EntryRow(
    e: RemoteEntry,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    menu: @Composable (close: () -> Unit) -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (selected) Modifier.background(MaterialTheme.colorScheme.secondaryContainer) else Modifier)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            when {
                selected -> Icons.Filled.CheckCircle
                e.isDir -> Icons.Filled.Folder
                e.name.endsWith(".zip", true) -> Icons.Filled.FolderZip
                else -> Icons.Filled.InsertDriveFile
            },
            null,
            Modifier.size(32.dp),
            tint = if (e.isDir || selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(e.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                listOf(fmtSize(e.size), fmtDate(e.modified)).filter { it.isNotEmpty() }.joinToString(" · "),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Box {
            IconButton({ open = true }) { Icon(Icons.Filled.MoreVert, "Действия") }
            DropdownMenu(open, { open = false }) { menu { open = false } }
        }
    }
}

@Composable
fun TextDialog(title: String, initial: String, ok: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true) },
        confirmButton = {
            TextButton({ if (text.isNotBlank()) { onOk(text.trim()); onDismiss() } }) { Text(ok) }
        },
        dismissButton = { TextButton(onDismiss) { Text("Отмена") } }
    )
}
