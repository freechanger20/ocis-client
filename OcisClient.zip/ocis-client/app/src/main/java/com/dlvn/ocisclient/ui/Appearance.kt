package com.dlvn.ocisclient.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.outlined.Android
import androidx.compose.material.icons.outlined.Article
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.InsertDriveFile
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Slideshow
import androidx.compose.material.icons.outlined.TableChart
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Article
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material.icons.sharp.Android
import androidx.compose.material.icons.sharp.Article
import androidx.compose.material.icons.sharp.CheckCircle
import androidx.compose.material.icons.sharp.Code
import androidx.compose.material.icons.sharp.Description
import androidx.compose.material.icons.sharp.Folder
import androidx.compose.material.icons.sharp.FolderZip
import androidx.compose.material.icons.sharp.Image
import androidx.compose.material.icons.sharp.InsertDriveFile
import androidx.compose.material.icons.sharp.Movie
import androidx.compose.material.icons.sharp.MusicNote
import androidx.compose.material.icons.sharp.PictureAsPdf
import androidx.compose.material.icons.sharp.Slideshow
import androidx.compose.material.icons.sharp.TableChart
import androidx.compose.material.icons.twotone.Android
import androidx.compose.material.icons.twotone.Article
import androidx.compose.material.icons.twotone.CheckCircle
import androidx.compose.material.icons.twotone.Code
import androidx.compose.material.icons.twotone.Description
import androidx.compose.material.icons.twotone.Folder
import androidx.compose.material.icons.twotone.FolderZip
import androidx.compose.material.icons.twotone.Image
import androidx.compose.material.icons.twotone.InsertDriveFile
import androidx.compose.material.icons.twotone.Movie
import androidx.compose.material.icons.twotone.MusicNote
import androidx.compose.material.icons.twotone.PictureAsPdf
import androidx.compose.material.icons.twotone.Slideshow
import androidx.compose.material.icons.twotone.TableChart
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

/** Палитра для акцента и цвета папок. */
val PALETTE: List<Pair<String, Color>> = listOf(
    "Синий" to Color(0xFF2F6FDB),
    "Голубой" to Color(0xFF0FA3D9),
    "Бирюзовый" to Color(0xFF0E9C8A),
    "Зелёный" to Color(0xFF3A9E3F),
    "Жёлтый" to Color(0xFFE0A100),
    "Оранжевый" to Color(0xFFE5711B),
    "Красный" to Color(0xFFD93B3B),
    "Розовый" to Color(0xFFD6407F),
    "Фиолетовый" to Color(0xFF8A4FD6),
    "Серый" to Color(0xFF6E7781),
)

fun paletteColor(i: Int): Color = PALETTE[i.coerceIn(0, PALETTE.size - 1)].second

val ICON_STYLES = listOf("Заливка", "Контур", "Скруглённые", "Острые", "Двухцветные")
val VIEW_MODES = listOf("Список", "Компактно", "Плитка")
val THEMES = listOf("Как в системе", "Светлая", "Тёмная")

enum class FileKind(val color: Color) {
    FOLDER(Color.Unspecified),
    IMAGE(Color(0xFF2E9E5B)),
    VIDEO(Color(0xFFD9483B)),
    AUDIO(Color(0xFF8A4FD6)),
    PDF(Color(0xFFD32F2F)),
    DOC(Color(0xFF2F6FDB)),
    SHEET(Color(0xFF1E8E3E)),
    SLIDES(Color(0xFFE5711B)),
    ARCHIVE(Color(0xFFB08A00)),
    CODE(Color(0xFF546E7A)),
    TEXT(Color(0xFF607D8B)),
    APK(Color(0xFF3DDC84)),
    OTHER(Color(0xFF78909C)),
}

private val EXT: Map<String, FileKind> = buildMap {
    listOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp", "svg", "tif", "tiff", "raw", "dng")
        .forEach { put(it, FileKind.IMAGE) }
    listOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "m4v", "wmv", "flv", "ts")
        .forEach { put(it, FileKind.VIDEO) }
    listOf("mp3", "flac", "wav", "ogg", "m4a", "aac", "opus", "wma", "amr")
        .forEach { put(it, FileKind.AUDIO) }
    put("pdf", FileKind.PDF)
    listOf("doc", "docx", "odt", "rtf").forEach { put(it, FileKind.DOC) }
    listOf("xls", "xlsx", "ods", "csv").forEach { put(it, FileKind.SHEET) }
    listOf("ppt", "pptx", "odp").forEach { put(it, FileKind.SLIDES) }
    listOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz").forEach { put(it, FileKind.ARCHIVE) }
    listOf("kt", "java", "py", "js", "ts", "json", "xml", "html", "css", "sh", "yml", "yaml", "c", "cpp", "go", "rs")
        .forEach { put(it, FileKind.CODE) }
    listOf("txt", "md", "log", "ini", "conf").forEach { put(it, FileKind.TEXT) }
    put("apk", FileKind.APK)
}

fun kindOf(name: String, isDir: Boolean): FileKind =
    if (isDir) FileKind.FOLDER else EXT[name.substringAfterLast('.', "").lowercase()] ?: FileKind.OTHER

@Suppress("DEPRECATION")
fun iconFor(kind: FileKind, style: Int): ImageVector = when (style) {
    1 -> when (kind) {
        FileKind.FOLDER -> Icons.Outlined.Folder
        FileKind.IMAGE -> Icons.Outlined.Image
        FileKind.VIDEO -> Icons.Outlined.Movie
        FileKind.AUDIO -> Icons.Outlined.MusicNote
        FileKind.PDF -> Icons.Outlined.PictureAsPdf
        FileKind.DOC -> Icons.Outlined.Article
        FileKind.SHEET -> Icons.Outlined.TableChart
        FileKind.SLIDES -> Icons.Outlined.Slideshow
        FileKind.ARCHIVE -> Icons.Outlined.FolderZip
        FileKind.CODE -> Icons.Outlined.Code
        FileKind.TEXT -> Icons.Outlined.Description
        FileKind.APK -> Icons.Outlined.Android
        FileKind.OTHER -> Icons.Outlined.InsertDriveFile
    }
    2 -> when (kind) {
        FileKind.FOLDER -> Icons.Rounded.Folder
        FileKind.IMAGE -> Icons.Rounded.Image
        FileKind.VIDEO -> Icons.Rounded.Movie
        FileKind.AUDIO -> Icons.Rounded.MusicNote
        FileKind.PDF -> Icons.Rounded.PictureAsPdf
        FileKind.DOC -> Icons.Rounded.Article
        FileKind.SHEET -> Icons.Rounded.TableChart
        FileKind.SLIDES -> Icons.Rounded.Slideshow
        FileKind.ARCHIVE -> Icons.Rounded.FolderZip
        FileKind.CODE -> Icons.Rounded.Code
        FileKind.TEXT -> Icons.Rounded.Description
        FileKind.APK -> Icons.Rounded.Android
        FileKind.OTHER -> Icons.Rounded.InsertDriveFile
    }
    3 -> when (kind) {
        FileKind.FOLDER -> Icons.Sharp.Folder
        FileKind.IMAGE -> Icons.Sharp.Image
        FileKind.VIDEO -> Icons.Sharp.Movie
        FileKind.AUDIO -> Icons.Sharp.MusicNote
        FileKind.PDF -> Icons.Sharp.PictureAsPdf
        FileKind.DOC -> Icons.Sharp.Article
        FileKind.SHEET -> Icons.Sharp.TableChart
        FileKind.SLIDES -> Icons.Sharp.Slideshow
        FileKind.ARCHIVE -> Icons.Sharp.FolderZip
        FileKind.CODE -> Icons.Sharp.Code
        FileKind.TEXT -> Icons.Sharp.Description
        FileKind.APK -> Icons.Sharp.Android
        FileKind.OTHER -> Icons.Sharp.InsertDriveFile
    }
    4 -> when (kind) {
        FileKind.FOLDER -> Icons.TwoTone.Folder
        FileKind.IMAGE -> Icons.TwoTone.Image
        FileKind.VIDEO -> Icons.TwoTone.Movie
        FileKind.AUDIO -> Icons.TwoTone.MusicNote
        FileKind.PDF -> Icons.TwoTone.PictureAsPdf
        FileKind.DOC -> Icons.TwoTone.Article
        FileKind.SHEET -> Icons.TwoTone.TableChart
        FileKind.SLIDES -> Icons.TwoTone.Slideshow
        FileKind.ARCHIVE -> Icons.TwoTone.FolderZip
        FileKind.CODE -> Icons.TwoTone.Code
        FileKind.TEXT -> Icons.TwoTone.Description
        FileKind.APK -> Icons.TwoTone.Android
        FileKind.OTHER -> Icons.TwoTone.InsertDriveFile
    }
    else -> when (kind) {
        FileKind.FOLDER -> Icons.Filled.Folder
        FileKind.IMAGE -> Icons.Filled.Image
        FileKind.VIDEO -> Icons.Filled.Movie
        FileKind.AUDIO -> Icons.Filled.MusicNote
        FileKind.PDF -> Icons.Filled.PictureAsPdf
        FileKind.DOC -> Icons.Filled.Article
        FileKind.SHEET -> Icons.Filled.TableChart
        FileKind.SLIDES -> Icons.Filled.Slideshow
        FileKind.ARCHIVE -> Icons.Filled.FolderZip
        FileKind.CODE -> Icons.Filled.Code
        FileKind.TEXT -> Icons.Filled.Description
        FileKind.APK -> Icons.Filled.Android
        FileKind.OTHER -> Icons.Filled.InsertDriveFile
    }
}

fun checkIcon(style: Int): ImageVector = when (style) {
    1 -> Icons.Outlined.CheckCircle
    2 -> Icons.Rounded.CheckCircle
    3 -> Icons.Sharp.CheckCircle
    4 -> Icons.TwoTone.CheckCircle
    else -> Icons.Filled.CheckCircle
}

private val TEXT_EXT = setOf(
    "txt", "md", "markdown", "log", "ini", "conf", "cfg", "config", "properties", "env", "toml",
    "xml", "html", "htm", "xhtml", "svg", "css", "scss", "less", "js", "mjs", "ts", "tsx", "jsx",
    "json", "jsonc", "yml", "yaml", "csv", "tsv", "sql", "sh", "bash", "zsh", "bat", "cmd", "ps1",
    "py", "kt", "kts", "java", "gradle", "c", "h", "cpp", "hpp", "cs", "go", "rs", "rb", "php",
    "pl", "lua", "swift", "dart", "r", "tex", "srt", "vtt", "sub", "ass", "nfo", "rtf", "diff",
    "patch", "gitignore", "dockerfile", "makefile", "service", "plist", "m3u", "m3u8", "reg", "desktop",
)

private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp", "avif")

private fun ext(name: String): String {
    val n = name.lowercase()
    return if (n.startsWith(".") && n.count { it == '.' } == 1) n.drop(1) else n.substringAfterLast('.', "")
}

/** Открывается во встроенном редакторе. */
fun isTextName(name: String, mime: String? = null): Boolean =
    ext(name) in TEXT_EXT || name.lowercase() in setOf("dockerfile", "makefile", "readme", "license") ||
        (mime != null && (mime.startsWith("text/") || mime.endsWith("+xml") || mime.endsWith("/json")))

/** Открывается во встроенном просмотрщике изображений. */
fun isImageName(name: String): Boolean = ext(name) in IMAGE_EXT
