package com.dlvn.ocisclient.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.compose.AsyncImagePainter
import coil.request.ImageRequest
import com.dlvn.ocisclient.App
import com.dlvn.ocisclient.net.RemoteEntry
import com.dlvn.ocisclient.util.fmtDate
import com.dlvn.ocisclient.util.fmtSize

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ViewerScreen(vm: MainViewModel, v: ViewerState, onDownload: (RemoteEntry) -> Unit) {
    val ctx = LocalContext.current
    val loader = remember { (ctx.applicationContext as App).imageLoader() }
    val pager = rememberPagerState(initialPage = v.start.coerceIn(0, (v.items.size - 1).coerceAtLeast(0))) { v.items.size }
    var bars by remember { mutableStateOf(true) }
    var info by remember { mutableStateOf(false) }
    var askDelete by remember { mutableStateOf(false) }
    val hq = remember { mutableStateOf(setOf<String>()) }

    BackHandler { vm.closeViewer() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (loader != null) {
            HorizontalPager(
                state = pager,
                beyondViewportPageCount = 1,
                key = { v.items[it].path },
                modifier = Modifier.fillMaxSize(),
            ) { page ->
                val e = v.items[page]
                ZoomImage(vm, e, loader, original = e.path in hq.value) { bars = !bars }
            }
        }

        val cur = v.items.getOrNull(pager.currentPage)
        AnimatedVisibility(bars && cur != null, enter = fadeIn(), exit = fadeOut()) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().background(Color(0x99000000)).statusBarsPadding()
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton({ vm.closeViewer() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад", tint = Color.White) }
                    Column(Modifier.weight(1f)) {
                        Text(cur?.name ?: "", color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${pager.currentPage + 1} из ${v.items.size}", color = Color(0xFFBBBBBB),
                            style = androidx.compose.material3.MaterialTheme.typography.labelSmall)
                    }
                    if (cur != null) {
                        IconButton({ hq.value = hq.value + cur.path }) {
                            Icon(Icons.Filled.HighQuality, "Оригинал",
                                tint = if (cur.path in hq.value) Color(0xFF8AB4F8) else Color.White)
                        }
                        IconButton({ onDownload(cur) }) { Icon(Icons.Filled.Download, "Скачать", tint = Color.White) }
                        IconButton({ info = true }) { Icon(Icons.Filled.Info, "Сведения", tint = Color.White) }
                        IconButton({ askDelete = true }) { Icon(Icons.Filled.Delete, "Удалить", tint = Color.White) }
                    }
                }
                Box(Modifier.weight(1f))
                Text(
                    "Двойное касание — увеличить · Кнопка HQ — оригинал",
                    Modifier.fillMaxWidth().background(Color(0x66000000)).navigationBarsPadding().padding(8.dp),
                    color = Color(0xFFBBBBBB), style = androidx.compose.material3.MaterialTheme.typography.labelSmall
                )
            }
        }
    }

    val cur = v.items.getOrNull(pager.currentPage)
    if (info && cur != null) AlertDialog(
        onDismissRequest = { info = false },
        title = { Text(cur.name) },
        text = { Text("Размер: ${fmtSize(cur.size)}\nИзменён: ${fmtDate(cur.modified)}\nПуть: ${cur.path}") },
        confirmButton = { TextButton({ info = false }) { Text("OK") } }
    )
    if (askDelete && cur != null) AlertDialog(
        onDismissRequest = { askDelete = false },
        title = { Text("Удалить ${cur.name}?") },
        confirmButton = { TextButton({ askDelete = false; vm.deleteFromViewer(cur) }) { Text("Удалить") } },
        dismissButton = { TextButton({ askDelete = false }) { Text("Отмена") } }
    )
}

/**
 * Фото с масштабированием щипком и двойным касанием.
 * Сначала грузится уменьшенная копия с сервера (быстро), при ошибке — оригинал.
 */
@Composable
private fun ZoomImage(vm: MainViewModel, e: RemoteEntry, loader: ImageLoader, original: Boolean, onTap: () -> Unit) {
    val ctx = LocalContext.current
    val dav = vm.dav() ?: return
    var fallback by remember(e.path) { mutableStateOf(false) }
    var state by remember(e.path) { mutableStateOf<AsyncImagePainter.State?>(null) }
    val gif = e.name.endsWith(".gif", true)
    val useOriginal = original || fallback || gif
    val url = if (useOriginal) dav.fileUrl(e.path, e.etag) else dav.previewUrl(e.path, 2560, e.etag)

    var scale by remember(e.path) { mutableFloatStateOf(1f) }
    var offset by remember(e.path) { mutableStateOf(Offset.Zero) }
    var size by remember { mutableStateOf(IntSize.Zero) }

    fun clamp(o: Offset, s: Float): Offset {
        val mx = (s - 1f) * size.width / 2f
        val my = (s - 1f) * size.height / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { size = it }
            .pointerInput(e.path) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { p ->
                        if (scale > 1.01f) { scale = 1f; offset = Offset.Zero }
                        else {
                            val s = 2.5f
                            val c = Offset(size.width / 2f, size.height / 2f)
                            scale = s
                            offset = clamp((c - p) * (s - 1f), s)
                        }
                    }
                )
            }
            .pointerInput(e.path) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        val fingers = event.changes.count { it.pressed }
                        if (fingers > 1 || scale > 1.01f) {
                            val zoom = event.calculateZoom()
                            val pan = event.calculatePan()
                            val ns = (scale * zoom).coerceIn(1f, 6f)
                            scale = ns
                            offset = if (ns <= 1.01f) Offset.Zero else clamp(offset + pan, ns)
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            },
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = ImageRequest.Builder(ctx).data(url).crossfade(true).build(),
            contentDescription = e.name,
            imageLoader = loader,
            contentScale = ContentScale.Fit,
            onState = { st ->
                state = st
                if (st is AsyncImagePainter.State.Error && !useOriginal) fallback = true
            },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale; scaleY = scale
                    translationX = offset.x; translationY = offset.y
                }
        )
        when (val st = state) {
            is AsyncImagePainter.State.Loading -> CircularProgressIndicator(color = Color.White)
            is AsyncImagePainter.State.Error -> if (useOriginal) Text(
                "Не удалось открыть: ${st.result.throwable.message ?: ""}", color = Color.White,
                modifier = Modifier.padding(24.dp)
            )
            else -> {}
        }
    }
}
