package com.dlvn.ocisclient.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class Account(
    val server: String,
    val user: String,
    val token: String,
)

data class Settings(
    /** Сколько файлов передаётся одновременно внутри одной задачи (папки). */
    val parallelFiles: Int = 4,
    /** На сколько частей делить один большой файл при скачивании. */
    val segments: Int = 4,
    /** Сколько задач из очереди выполняются одновременно. */
    val parallelTasks: Int = 2,
    /** Уровень сжатия ZIP: 0 — без сжатия (быстро), 9 — максимум. */
    val zipLevel: Int = 1,
    /** Папка на телефоне для скачанных файлов (SAF tree uri). */
    val downloadTree: String? = null,
)

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("ocis", Context.MODE_PRIVATE)

    private val _account = MutableStateFlow(readAccount())
    val account: StateFlow<Account?> = _account

    private val _settings = MutableStateFlow(readSettings())
    val settings: StateFlow<Settings> = _settings

    private fun readAccount(): Account? {
        val s = sp.getString("server", null) ?: return null
        val u = sp.getString("user", null) ?: return null
        val t = sp.getString("token", null) ?: return null
        return Account(s, u, t)
    }

    fun saveAccount(a: Account?) {
        sp.edit().apply {
            if (a == null) {
                remove("user"); remove("token")
            } else {
                putString("server", a.server); putString("user", a.user); putString("token", a.token)
            }
        }.apply()
        _account.value = a
    }

    fun lastServer(): String = sp.getString("server", null) ?: "https://ocis.dlvncloud.com"
    fun lastUser(): String = sp.getString("user", null) ?: ""

    private fun readSettings() = Settings(
        parallelFiles = sp.getInt("parallelFiles", 4),
        segments = sp.getInt("segments", 4),
        parallelTasks = sp.getInt("parallelTasks", 2),
        zipLevel = sp.getInt("zipLevel", 1),
        downloadTree = sp.getString("downloadTree", null),
    )

    fun saveSettings(s: Settings) {
        sp.edit()
            .putInt("parallelFiles", s.parallelFiles)
            .putInt("segments", s.segments)
            .putInt("parallelTasks", s.parallelTasks)
            .putInt("zipLevel", s.zipLevel)
            .putString("downloadTree", s.downloadTree)
            .apply()
        _settings.value = s
    }

    fun downloadTreeUri(): Uri? = settings.value.downloadTree?.let(Uri::parse)
}
