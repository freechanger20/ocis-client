package com.dlvn.ocisclient.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class Account(
    val server: String,
    val user: String,
    val token: String,
)

data class Settings(
    /** Сколько файлов передаётся одновременно внутри одной задачи (папки). */
    val parallelFiles: Int = 4,
    /** На сколько частей делить один большой файл при скачивании. */
    val segments: Int = 4,
    /** Сколько задач из очереди выполняются одновременно. */
    val parallelTasks: Int = 2,
    /** Уровень сжатия ZIP: 0 — без сжатия (быстро), 9 — максимум. */
    val zipLevel: Int = 1,
    /** Папка на телефоне для скачанных файлов (SAF tree uri). */
    val downloadTree: String? = null,

    // ----- Внешний вид -----
    /** 0 — как в системе, 1 — светлая, 2 — тёмная. */
    val theme: Int = 0,
    /** Индекс акцентного цвета в палитре. */
    val accent: Int = 0,
    /** 0 — список, 1 — компактный список, 2 — плитка. */
    val viewMode: Int = 0,
    /** Множитель размера шрифта. */
    val fontScale: Float = 1f,
    /** Вертикальный отступ строки, dp. */
    val rowSpacing: Int = 10,
    /** Размер иконок в списке, dp. */
    val iconSize: Int = 32,
    /** 0 — заливка, 1 — контур, 2 — скруглённые, 3 — острые, 4 — двухцветные. */
    val iconStyle: Int = 0,
    /** Разные цвета иконок по типу файла. */
    val coloredIcons: Boolean = true,
    /** Индекс цвета папок по умолчанию. */
    val folderColor: Int = 0,
    /** Показывать размер и дату под именем. */
    val showDetails: Boolean = true,
    /** Колонок в режиме плитки. */
    val gridColumns: Int = 3,
    /** Разделители между строками списка. */
    val dividers: Boolean = false,
    /** Миниатюры фото в списке и плитке. */
    val thumbnails: Boolean = true,

    // ----- Редактор -----
    val editorFont: Int = 15,
    val editorWrap: Boolean = true,
    val editorMono: Boolean = true,
)

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("ocis", Context.MODE_PRIVATE)

    private val _account = MutableStateFlow(readAccount())
    val account: StateFlow<Account?> = _account

    private val _settings = MutableStateFlow(readSettings())
    val settings: StateFlow<Settings> = _settings

    private fun readAccount(): Account? {
        val s = sp.getString("server", null) ?: return null
        val u = sp.getString("user", null) ?: return null
        val t = sp.getString("token", null) ?: return null
        return Account(s, u, t)
    }

    fun saveAccount(a: Account?) {
        sp.edit().apply {
            if (a == null) {
                remove("user"); remove("token")
            } else {
                putString("server", a.server); putString("user", a.user); putString("token", a.token)
            }
        }.apply()
        _account.value = a
    }

    fun lastServer(): String = sp.getString("server", null) ?: "https://ocis.dlvncloud.com"
    fun lastUser(): String = sp.getString("user", null) ?: ""

    private fun readSettings() = Settings(
        parallelFiles = sp.getInt("parallelFiles", 4),
        segments = sp.getInt("segments", 4),
        parallelTasks = sp.getInt("parallelTasks", 2),
        zipLevel = sp.getInt("zipLevel", 1),
        downloadTree = sp.getString("downloadTree", null),
        theme = sp.getInt("theme", 0),
        accent = sp.getInt("accent", 0),
        viewMode = sp.getInt("viewMode", 0),
        fontScale = sp.getFloat("fontScale", 1f),
        rowSpacing = sp.getInt("rowSpacing", 10),
        iconSize = sp.getInt("iconSize", 32),
        iconStyle = sp.getInt("iconStyle", 0),
        coloredIcons = sp.getBoolean("coloredIcons", true),
        folderColor = sp.getInt("folderColor", 0),
        showDetails = sp.getBoolean("showDetails", true),
        gridColumns = sp.getInt("gridColumns", 3),
        dividers = sp.getBoolean("dividers", false),
        thumbnails = sp.getBoolean("thumbnails", true),
        editorFont = sp.getInt("editorFont", 15),
        editorWrap = sp.getBoolean("editorWrap", true),
        editorMono = sp.getBoolean("editorMono", true),
    )

    fun saveSettings(s: Settings) {
        sp.edit()
            .putInt("parallelFiles", s.parallelFiles)
            .putInt("segments", s.segments)
            .putInt("parallelTasks", s.parallelTasks)
            .putInt("zipLevel", s.zipLevel)
            .putString("downloadTree", s.downloadTree)
            .putInt("theme", s.theme)
            .putInt("accent", s.accent)
            .putInt("viewMode", s.viewMode)
            .putFloat("fontScale", s.fontScale)
            .putInt("rowSpacing", s.rowSpacing)
            .putInt("iconSize", s.iconSize)
            .putInt("iconStyle", s.iconStyle)
            .putBoolean("coloredIcons", s.coloredIcons)
            .putInt("folderColor", s.folderColor)
            .putBoolean("showDetails", s.showDetails)
            .putInt("gridColumns", s.gridColumns)
            .putBoolean("dividers", s.dividers)
            .putBoolean("thumbnails", s.thumbnails)
            .putInt("editorFont", s.editorFont)
            .putBoolean("editorWrap", s.editorWrap)
            .putBoolean("editorMono", s.editorMono)
            .apply()
        _settings.value = s
    }

    // ----- Цвета отдельных папок (путь → индекс цвета) -----
    private val _folderColors = MutableStateFlow(readFolderColors())
    val folderColors: StateFlow<Map<String, Int>> = _folderColors

    private fun readFolderColors(): Map<String, Int> =
        (sp.getString("folderColors", "") ?: "").split('\n').mapNotNull {
            val i = it.lastIndexOf('\u0001')
            if (i <= 0) null else it.substring(0, i) to (it.substring(i + 1).toIntOrNull() ?: return@mapNotNull null)
        }.toMap()

    fun setFolderColor(path: String, color: Int?) {
        val m = _folderColors.value.toMutableMap()
        if (color == null) m.remove(path) else m[path] = color
        sp.edit().putString("folderColors", m.entries.joinToString("\n") { "${it.key}\u0001${it.value}" }).apply()
        _folderColors.value = m
    }

    fun downloadTreeUri(): Uri? = settings.value.downloadTree?.let(Uri::parse)
}
