package com.dlvn.ocisclient.util

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/** Определение кодировки и концов строк для текстового редактора. */
object TextCodec {

    val CP1251: Charset = Charset.forName("windows-1251")
    val CHARSETS: List<Charset> = listOf(
        Charsets.UTF_8, CP1251, Charset.forName("KOI8-R"), Charset.forName("IBM866"),
        Charsets.UTF_16LE, Charsets.UTF_16BE, Charsets.ISO_8859_1,
    )

    class Decoded(
        val text: String,
        val charset: Charset,
        val bom: ByteArray,
        val crlf: Boolean,
        val looksBinary: Boolean,
    )

    private val BOM_UTF8 = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
    private val BOM_LE = byteArrayOf(0xFF.toByte(), 0xFE.toByte())
    private val BOM_BE = byteArrayOf(0xFE.toByte(), 0xFF.toByte())

    private fun startsWith(b: ByteArray, p: ByteArray) =
        b.size >= p.size && p.indices.all { b[it] == p[it] }

    /** Автоопределение: BOM → строгий UTF-8 → Windows-1251. */
    fun decode(b: ByteArray, forced: Charset? = null): Decoded {
        var bom = ByteArray(0)
        val cs: Charset = when {
            startsWith(b, BOM_UTF8) -> { bom = BOM_UTF8; Charsets.UTF_8 }
            startsWith(b, BOM_LE) -> { bom = BOM_LE; Charsets.UTF_16LE }
            startsWith(b, BOM_BE) -> { bom = BOM_BE; Charsets.UTF_16BE }
            forced != null -> forced
            isStrictUtf8(b) -> Charsets.UTF_8
            else -> CP1251
        }
        val useCs = forced ?: cs
        val raw = String(b, bom.size, b.size - bom.size, useCs)
        val crlf = raw.contains("\r\n")
        val text = if (crlf) raw.replace("\r\n", "\n") else raw
        val head = b.copyOf(minOf(b.size, 8192))
        val zeros = if (useCs == Charsets.UTF_16LE || useCs == Charsets.UTF_16BE) 0 else head.count { it == 0.toByte() }
        return Decoded(text, useCs, bom, crlf, zeros > 2)
    }

    fun encode(text: String, cs: Charset, bom: ByteArray, crlf: Boolean): ByteArray {
        val t = if (crlf) text.replace("\n", "\r\n") else text
        return bom + t.toByteArray(cs)
    }

    private fun isStrictUtf8(b: ByteArray): Boolean = try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(b))
        true
    } catch (_: CharacterCodingException) {
        false
    }

    fun label(cs: Charset): String = when (cs.name().uppercase()) {
        "UTF-8" -> "UTF-8"
        "WINDOWS-1251" -> "Windows-1251"
        "KOI8-R" -> "KOI8-R"
        "IBM866" -> "DOS-866"
        "UTF-16LE" -> "UTF-16 LE"
        "UTF-16BE" -> "UTF-16 BE"
        "ISO-8859-1" -> "Latin-1"
        else -> cs.name()
    }
}
