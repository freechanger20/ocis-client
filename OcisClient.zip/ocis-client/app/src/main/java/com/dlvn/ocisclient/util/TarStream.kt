package com.dlvn.ocisclient.util

import java.io.EOFException
import java.io.InputStream

/**
 * Потоковое чтение tar (ustar + PAX + GNU longname), без временных файлов.
 * Используется для скачивания папок через серверный архиватор с распаковкой "на лету".
 */
class TarStream(private val input: InputStream) {

    class Entry(val name: String, val isDir: Boolean, val size: Long, val mtimeMs: Long)

    private var remaining = 0L
    private var padding = 0L
    private val header = ByteArray(512)

    /** Возвращает следующую запись или null в конце архива. */
    fun next(): Entry? {
        skipRest()
        var paxPath: String? = null
        var paxSize: Long? = null
        var longName: String? = null
        while (true) {
            if (!readFully(header)) return null
            if (header.all { it == 0.toByte() }) return null
            val type = header[156].toInt().toChar()
            var size = parseOctal(header, 124, 12)
            val mtime = parseOctal(header, 136, 12) * 1000
            when (type) {
                'x', 'g' -> {
                    val data = readBlock(size)
                    if (type == 'x') {
                        val rec = parsePax(data)
                        rec["path"]?.let { paxPath = it }
                        rec["size"]?.toLongOrNull()?.let { paxSize = it }
                    }
                    continue
                }
                'L' -> {
                    longName = String(readBlock(size), Charsets.UTF_8).trimEnd('\u0000')
                    continue
                }
            }
            paxSize?.let { size = it }
            val name = paxPath ?: longName ?: run {
                val n = cstr(header, 0, 100)
                val prefix = if (String(header, 257, 5, Charsets.US_ASCII) == "ustar") cstr(header, 345, 155) else ""
                if (prefix.isNotEmpty()) "$prefix/$n" else n
            }
            val isDir = type == '5' || name.endsWith("/")
            remaining = if (type == '0' || type == '\u0000' || type == '7') size else if (isDir) 0 else size
            padding = (512 - (size % 512)) % 512
            if (isDir) { remaining = 0 }
            return Entry(name.trimEnd('/'), isDir, if (isDir) 0 else size, mtime)
        }
    }

    /** Поток содержимого текущей записи. */
    val entryStream: InputStream = object : InputStream() {
        override fun read(): Int {
            if (remaining <= 0) return -1
            val b = input.read()
            if (b >= 0) remaining--
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (remaining <= 0) return -1
            val n = input.read(b, off, minOf(len.toLong(), remaining).toInt())
            if (n > 0) remaining -= n
            if (n < 0) throw EOFException("Архив оборвался")
            return n
        }
    }

    private fun skipRest() {
        val buf = ByteArray(64 * 1024)
        while (remaining > 0) {
            val n = input.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
            if (n < 0) throw EOFException()
            remaining -= n
        }
        skipBytes(padding)
        padding = 0
    }

    private fun skipBytes(n: Long) {
        var left = n
        val buf = ByteArray(512)
        while (left > 0) {
            val r = input.read(buf, 0, minOf(512L, left).toInt())
            if (r < 0) throw EOFException()
            left -= r
        }
    }

    private fun readBlock(size: Long): ByteArray {
        val data = ByteArray(size.toInt())
        if (!readFully(data)) throw EOFException()
        skipBytes((512 - (size % 512)) % 512)
        return data
    }

    private fun readFully(b: ByteArray): Boolean {
        var off = 0
        while (off < b.size) {
            val n = input.read(b, off, b.size - off)
            if (n < 0) { if (off == 0) return false else throw EOFException() }
            off += n
        }
        return true
    }

    private fun cstr(b: ByteArray, off: Int, len: Int): String {
        var end = off
        while (end < off + len && b[end] != 0.toByte()) end++
        return String(b, off, end - off, Charsets.UTF_8)
    }

    private fun parseOctal(b: ByteArray, off: Int, len: Int): Long {
        // Бинарный формат больших чисел (base-256)
        if (b[off].toInt() and 0x80 != 0) {
            var v = 0L
            for (i in off + 1 until off + len) v = (v shl 8) or (b[i].toLong() and 0xff)
            return v
        }
        val s = cstr(b, off, len).trim()
        return if (s.isEmpty()) 0 else s.toLong(8)
    }

    private fun parsePax(data: ByteArray): Map<String, String> {
        val map = HashMap<String, String>()
        var i = 0
        while (i < data.size) {
            var sp = i
            while (sp < data.size && data[sp] != ' '.code.toByte()) sp++
            if (sp >= data.size) break
            val len = String(data, i, sp - i, Charsets.US_ASCII).toIntOrNull() ?: break
            val rec = String(data, sp + 1, len - (sp - i) - 2, Charsets.UTF_8)
            val eq = rec.indexOf('=')
            if (eq > 0) map[rec.substring(0, eq)] = rec.substring(eq + 1)
            i += len
        }
        return map
    }
}
