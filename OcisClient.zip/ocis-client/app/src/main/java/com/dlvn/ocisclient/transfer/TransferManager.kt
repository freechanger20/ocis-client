package com.dlvn.ocisclient.transfer

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

enum class Kind { UPLOAD, DOWNLOAD }
enum class TState { QUEUED, RUNNING, DONE, FAILED, CANCELLED }

class Task(
    val id: Long,
    val kind: Kind,
    val title: String,
    /** Папка в облаке, содержимое которой меняется (для автообновления списка). */
    val remoteDir: String?,
    val work: suspend (Task) -> Unit,
) {
    val total = AtomicLong(0)
    val done = AtomicLong(0)
    val filesTotal = AtomicInteger(0)
    val filesDone = AtomicInteger(0)
    val filesSkipped = AtomicInteger(0)
    @Volatile var state = TState.QUEUED
    @Volatile var error: String? = null
    @Volatile var phase: String = ""
    @Volatile var job: Job? = null

    // для расчёта скорости
    var lastBytes = 0L
    var speed = 0L
    var startedAt = 0L
    var finishedAt = 0L

    fun add(n: Long) { done.addAndGet(n) }
}

data class TaskUi(
    val id: Long,
    val kind: Kind,
    val title: String,
    val state: TState,
    val total: Long,
    val done: Long,
    val filesTotal: Int,
    val filesDone: Int,
    val filesSkipped: Int,
    val speed: Long,
    val avgSpeed: Long,
    val phase: String,
    val error: String?,
)

class TransferManager(private val ctx: Context, parallelTasks: () -> Int) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val tasks = CopyOnWriteArrayList<Task>()
    private val ids = AtomicLong(1)
    private val slots = Semaphore(parallelTasks().coerceIn(1, 4))

    private val _ui = MutableStateFlow<List<TaskUi>>(emptyList())
    val ui: StateFlow<List<TaskUi>> = _ui

    private val _changed = MutableSharedFlow<String>(extraBufferCapacity = 16)
    /** Пути папок в облаке, где что-то изменилось после завершения задачи. */
    val changed: SharedFlow<String> = _changed

    private var ticker: Job? = null

    fun hasActive() = tasks.any { it.state == TState.QUEUED || it.state == TState.RUNNING }

    fun enqueue(kind: Kind, title: String, remoteDir: String?, work: suspend (Task) -> Unit): Task {
        val t = Task(ids.getAndIncrement(), kind, title, remoteDir, work)
        tasks.add(0, t)
        start(t)
        return t
    }

    private fun start(t: Task) {
        t.job = scope.launch {
            slots.withPermit {
                if (t.state == TState.CANCELLED) return@withPermit
                t.state = TState.RUNNING
                t.startedAt = System.currentTimeMillis()
                try {
                    t.work(t)
                    t.state = TState.DONE
                } catch (e: CancellationException) {
                    t.state = TState.CANCELLED
                } catch (e: Throwable) {
                    t.state = TState.FAILED
                    t.error = e.message ?: e.javaClass.simpleName
                } finally {
                    t.finishedAt = System.currentTimeMillis()
                    t.remoteDir?.let { _changed.tryEmit(it) }
                    publish()
                }
            }
        }
        ensureTicker()
        ContextCompat.startForegroundService(ctx, Intent(ctx, TransferService::class.java))
    }

    fun cancel(id: Long) {
        tasks.firstOrNull { it.id == id }?.let {
            if (it.state == TState.QUEUED || it.state == TState.RUNNING) {
                it.state = TState.CANCELLED
                it.job?.cancel()
            }
        }
        publish()
    }

    /** Повтор задачи. Уже переданные файлы (такого же размера) будут пропущены. */
    fun retry(id: Long) {
        val old = tasks.firstOrNull { it.id == id } ?: return
        tasks.remove(old)
        enqueue(old.kind, old.title, old.remoteDir, old.work)
    }

    fun clearFinished() {
        tasks.removeAll { it.state == TState.DONE || it.state == TState.CANCELLED || it.state == TState.FAILED }
        publish()
    }

    private fun ensureTicker() {
        if (ticker?.isActive == true) return
        ticker = scope.launch {
            while (isActive) {
                publish()
                delay(500)
                if (!hasActive()) { publish(); break }
            }
        }
    }

    @Synchronized
    private fun publish() {
        val now = System.currentTimeMillis()
        _ui.value = tasks.map { t ->
            val d = t.done.get()
            if (t.state == TState.RUNNING) {
                val delta = d - t.lastBytes
                // сглаживание скорости
                t.speed = (t.speed * 0.6 + (delta * 2) * 0.4).toLong().coerceAtLeast(0)
            } else t.speed = 0
            t.lastBytes = d
            val elapsed = ((if (t.finishedAt > 0) t.finishedAt else now) - t.startedAt).coerceAtLeast(1)
            TaskUi(
                id = t.id, kind = t.kind, title = t.title, state = t.state,
                total = t.total.get(), done = d,
                filesTotal = t.filesTotal.get(), filesDone = t.filesDone.get(),
                filesSkipped = t.filesSkipped.get(),
                speed = t.speed,
                avgSpeed = if (t.startedAt > 0) d * 1000 / elapsed else 0,
                phase = t.phase, error = t.error,
            )
        }
    }
}
