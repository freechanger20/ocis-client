package com.dlvn.ocisclient.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dlvn.ocisclient.App
import com.dlvn.ocisclient.data.Account
import com.dlvn.ocisclient.data.Settings
import com.dlvn.ocisclient.net.RemoteEntry
import com.dlvn.ocisclient.net.WebDav
import com.dlvn.ocisclient.transfer.Kind
import com.dlvn.ocisclient.transfer.joinPath
import com.dlvn.ocisclient.util.Saf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class SortMode { NAME, DATE, SIZE }

/** Отложенное действие, ожидающее выбора папки для скачивания. */
sealed interface Pending {
    data class File(val e: RemoteEntry) : Pending
    data class Dir(val e: RemoteEntry) : Pending
    data class Archive(val e: RemoteEntry, val unpack: Boolean) : Pending
    data class Many(val list: List<Pending>) : Pending
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as App
    val prefs = a.prefs
    val transfers = a.transfers

    private val _path = MutableStateFlow("/")
    val path: StateFlow<String> = _path

    private val _entries = MutableStateFlow<List<RemoteEntry>>(emptyList())
    val entries: StateFlow<List<RemoteEntry>> = _entries

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    private val _sort = MutableStateFlow(SortMode.NAME)
    val sort: StateFlow<SortMode> = _sort

    private val _filter = MutableStateFlow("")
    val filter: StateFlow<String> = _filter

    var pending: Pending? = null

    /** Кеш списков папок: мгновенный показ при возврате назад, обновление в фоне. */
    private val cache = HashMap<String, List<RemoteEntry>>()

    init {
        viewModelScope.launch {
            transfers.changed.collect { dir ->
                if (dir.trimEnd('/') == _path.value.trimEnd('/')) refresh()
            }
        }
    }

    fun consumeMessage() { _message.value = null }
    fun toast(s: String) { _message.value = s }

    fun setSort(s: SortMode) { _sort.value = s }
    fun setFilter(s: String) { _filter.value = s }

    suspend fun login(server: String, user: String, token: String): String? = withContext(Dispatchers.IO) {
        try {
            val acc = Account(server.trim().trimEnd('/'), user.trim(), token.trim())
            WebDav(acc).list("/")
            prefs.saveAccount(acc)
            cache.clear()
            open("/")
            null
        } catch (e: Exception) {
            e.message ?: e.javaClass.simpleName
        }
    }

    fun logout() {
        prefs.saveAccount(null)
        cache.clear()
        _entries.value = emptyList()
        _path.value = "/"
    }

    fun open(p: String) {
        _path.value = p
        _filter.value = ""
        _entries.value = cache[p] ?: emptyList()
        refresh()
    }

    fun up(): Boolean {
        val p = _path.value.trimEnd('/')
        if (p.isEmpty() || p == "/") return false
        open(p.substringBeforeLast('/').ifEmpty { "/" })
        return true
    }

    fun refresh() {
        val dav = a.dav() ?: return
        val p = _path.value
        viewModelScope.launch {
            _loading.value = true
            try {
                val list = withContext(Dispatchers.IO) { dav.list(p) }
                cache[p] = list
                if (_path.value == p) _entries.value = list
            } catch (e: Exception) {
                _message.value = e.message ?: "Ошибка"
            } finally {
                _loading.value = false
            }
        }
    }

    private fun io(okMsg: String? = null, block: suspend (WebDav) -> Unit) {
        val dav = a.dav() ?: return
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { block(dav) }
                okMsg?.let { _message.value = it }
            } catch (e: Exception) {
                _message.value = e.message ?: "Ошибка"
            }
            refresh()
        }
    }

    fun mkdir(name: String) = io { it.mkcol(joinPath(_path.value, name)) }
    fun rename(e: RemoteEntry, newName: String) =
        io { it.move(e.path, joinPath(e.path.substringBeforeLast('/'), newName)) }
    fun delete(list: List<RemoteEntry>) = io("Удалено: ${list.size}") { d -> list.forEach { d.delete(it.path) } }
    fun moveTo(list: List<RemoteEntry>, targetDir: String) =
        io("Перемещено: ${list.size}") { d -> list.forEach { d.move(it.path, joinPath(targetDir, it.name)) } }

    // ---------- Передачи ----------

    fun uploadFiles(uris: List<Uri>) {
        val ops = a.ops() ?: return
        val dir = _path.value
        val title = if (uris.size == 1) Saf.displayName(a, uris[0]) else "${uris.size} файлов"
        transfers.enqueue(Kind.UPLOAD, "↑ $title", dir) { ops.uploadFiles(it, uris, dir) }
    }

    fun uploadTree(tree: Uri, asZip: Boolean) {
        val ops = a.ops() ?: return
        val dir = _path.value
        val name = Saf.treeName(a, tree)
        if (asZip) transfers.enqueue(Kind.UPLOAD, "↑ $name.zip", dir) { ops.uploadTreeAsZip(it, tree, dir) }
        else transfers.enqueue(Kind.UPLOAD, "↑ $name/", dir) { ops.uploadTree(it, tree, dir) }
    }

    fun hasDownloadTree() = prefs.settings.value.downloadTree != null

    fun setDownloadTree(uri: Uri) {
        prefs.saveSettings(prefs.settings.value.copy(downloadTree = uri.toString()))
    }

    fun runPending() {
        val p = pending ?: return
        pending = null
        val ops = a.ops() ?: return
        enqueue(ops, p)
        _message.value = "Добавлено в передачи"
    }

    private fun enqueue(ops: com.dlvn.ocisclient.transfer.Ops, p: Pending) {
        when (p) {
            is Pending.File -> transfers.enqueue(Kind.DOWNLOAD, "↓ ${p.e.name}", null) { ops.downloadFile(it, p.e) }
            is Pending.Dir -> transfers.enqueue(Kind.DOWNLOAD, "↓ ${p.e.name}/", null) { ops.downloadDir(it, p.e) }
            is Pending.Archive -> transfers.enqueue(
                Kind.DOWNLOAD, if (p.unpack) "↓ ${p.e.name}/ (одним потоком)" else "↓ ${p.e.name}.zip", null
            ) { ops.downloadArchive(it, p.e, p.unpack) }
            is Pending.Many -> p.list.forEach { enqueue(ops, it) }
        }
    }

    fun saveSettings(s: Settings) = prefs.saveSettings(s)
}
