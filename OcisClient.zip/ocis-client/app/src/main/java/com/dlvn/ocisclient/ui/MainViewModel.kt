package com.dlvn.ocisclient.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dlvn.ocisclient.App
import com.dlvn.ocisclient.data.Account
import com.dlvn.ocisclient.data.Settings
import com.dlvn.ocisclient.net.RemoteEntry
import com.dlvn.ocisclient.net.WebDav
import com.dlvn.ocisclient.transfer.Kind
import com.dlvn.ocisclient.transfer.joinPath
import com.dlvn.ocisclient.util.Saf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.TextFieldValue
import com.dlvn.ocisclient.net.HttpError
import com.dlvn.ocisclient.util.TextCodec
import java.nio.charset.Charset
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class SortMode { NAME, DATE, SIZE }

/** Отложенное действие, ожидающее выбора папки для скачивания. */
sealed interface Pending {
    data class File(val e: RemoteEntry) : Pending
    data class Dir(val e: RemoteEntry) : Pending
    data class Archive(val e: RemoteEntry, val unpack: Boolean) : Pending
    data class Many(val list: List<Pending>) : Pending
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as App
    val prefs = a.prefs
    val transfers = a.transfers

    private val _path = MutableStateFlow("/")
    val path: StateFlow<String> = _path

    private val _entries = MutableStateFlow<List<RemoteEntry>>(emptyList())
    val entries: StateFlow<List<RemoteEntry>> = _entries

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    private val _sort = MutableStateFlow(SortMode.NAME)
    val sort: StateFlow<SortMode> = _sort

    private val _filter = MutableStateFlow("")
    val filter: StateFlow<String> = _filter

    var pending: Pending? = null

    /** Кеш списков папок: мгновенный показ при возврате назад, обновление в фоне. */
    private val cache = HashMap<String, List<RemoteEntry>>()

    init {
        viewModelScope.launch {
            transfers.changed.collect { dir ->
                if (dir.trimEnd('/') == _path.value.trimEnd('/')) refresh()
            }
        }
    }

    fun consumeMessage() { _message.value = null }
    fun toast(s: String) { _message.value = s }

    fun setSort(s: SortMode) { _sort.value = s }
    fun setFilter(s: String) { _filter.value = s }

    suspend fun login(server: String, user: String, token: String): String? = withContext(Dispatchers.IO) {
        try {
            val acc = Account(server.trim().trimEnd('/'), user.trim(), token.trim())
            WebDav(acc).list("/")
            prefs.saveAccount(acc)
            cache.clear()
            open("/")
            null
        } catch (e: Exception) {
            e.message ?: e.javaClass.simpleName
        }
    }

    fun logout() {
        prefs.saveAccount(null)
        cache.clear()
        _entries.value = emptyList()
        _path.value = "/"
    }

    fun open(p: String) {
        _path.value = p
        _filter.value = ""
        _entries.value = cache[p] ?: emptyList()
        refresh()
    }

    fun up(): Boolean {
        val p = _path.value.trimEnd('/')
        if (p.isEmpty() || p == "/") return false
        open(p.substringBeforeLast('/').ifEmpty { "/" })
        return true
    }

    fun refresh() {
        val dav = a.dav() ?: return
        val p = _path.value
        viewModelScope.launch {
            _loading.value = true
            try {
                val list = withContext(Dispatchers.IO) { dav.list(p) }
                cache[p] = list
                if (_path.value == p) _entries.value = list
            } catch (e: Exception) {
                _message.value = e.message ?: "Ошибка"
            } finally {
                _loading.value = false
            }
        }
    }

    private fun io(okMsg: String? = null, block: suspend (WebDav) -> Unit) {
        val dav = a.dav() ?: return
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { block(dav) }
                okMsg?.let { _message.value = it }
            } catch (e: Exception) {
                _message.value = e.message ?: "Ошибка"
            }
            refresh()
        }
    }

    fun mkdir(name: String) = io { it.mkcol(joinPath(_path.value, name)) }
    fun rename(e: RemoteEntry, newName: String) =
        io { it.move(e.path, joinPath(e.path.substringBeforeLast('/'), newName)) }
    fun delete(list: List<RemoteEntry>) = io("Удалено: ${list.size}") { d -> list.forEach { d.delete(it.path) } }
    fun moveTo(list: List<RemoteEntry>, targetDir: String) =
        io("Перемещено: ${list.size}") { d -> list.forEach { d.move(it.path, joinPath(targetDir, it.name)) } }

    // ---------- Передачи ----------

    fun uploadFiles(uris: List<Uri>) {
        val ops = a.ops() ?: return
        val dir = _path.value
        val title = if (uris.size == 1) Saf.displayName(a, uris[0]) else "${uris.size} файлов"
        transfers.enqueue(Kind.UPLOAD, "↑ $title", dir) { ops.uploadFiles(it, uris, dir) }
    }

    fun uploadTree(tree: Uri, asZip: Boolean) {
        val ops = a.ops() ?: return
        val dir = _path.value
        val name = Saf.treeName(a, tree)
        if (asZip) transfers.enqueue(Kind.UPLOAD, "↑ $name.zip", dir) { ops.uploadTreeAsZip(it, tree, dir) }
        else transfers.enqueue(Kind.UPLOAD, "↑ $name/", dir) { ops.uploadTree(it, tree, dir) }
    }

    fun hasDownloadTree() = prefs.settings.value.downloadTree != null

    fun setDownloadTree(uri: Uri) {
        prefs.saveSettings(prefs.settings.value.copy(downloadTree = uri.toString()))
    }

    fun runPending() {
        val p = pending ?: return
        pending = null
        val ops = a.ops() ?: return
        enqueue(ops, p)
        _message.value = "Добавлено в передачи"
    }

    private fun enqueue(ops: com.dlvn.ocisclient.transfer.Ops, p: Pending) {
        when (p) {
            is Pending.File -> transfers.enqueue(Kind.DOWNLOAD, "↓ ${p.e.name}", null) { ops.downloadFile(it, p.e) }
            is Pending.Dir -> transfers.enqueue(Kind.DOWNLOAD, "↓ ${p.e.name}/", null) { ops.downloadDir(it, p.e) }
            is Pending.Archive -> transfers.enqueue(
                Kind.DOWNLOAD, if (p.unpack) "↓ ${p.e.name}/ (одним потоком)" else "↓ ${p.e.name}.zip", null
            ) { ops.downloadArchive(it, p.e, p.unpack) }
            is Pending.Many -> p.list.forEach { enqueue(ops, it) }
        }
    }

    fun saveSettings(s: Settings) = prefs.saveSettings(s)

    fun dav(): WebDav? = a.dav()

    // ---------- Текстовый редактор ----------

    var editor by mutableStateOf<EditorState?>(null)
        private set

    fun openEditor(e: RemoteEntry) {
        val st = EditorState(e)
        editor = st
        load(st)
    }

    fun closeEditor() { editor = null; refresh() }

    fun reloadEditor() { editor?.let { it.loading = true; it.error = null; load(it) } }

    private fun load(st: EditorState) {
        val dav = a.dav() ?: return
        viewModelScope.launch {
            try {
                val (bytes, etag) = withContext(Dispatchers.IO) { dav.getBytes(st.entry.path, EditorState.MAX_VIEW) }
                st.raw = bytes
                st.etag = etag ?: st.entry.etag
                val d = withContext(Dispatchers.Default) { TextCodec.decode(bytes) }
                st.apply(d)
                st.readOnly = bytes.size > EditorState.MAX_EDIT
            } catch (e: Exception) {
                st.error = e.message ?: "Ошибка"
            } finally {
                st.loading = false
            }
        }
    }

    /** Перечитать файл в другой кодировке (только без несохранённых правок). */
    fun changeCharset(cs: Charset) {
        val st = editor ?: return
        st.apply(TextCodec.decode(st.raw, cs))
    }

    /** Сохранение. force = перезаписать, даже если файл изменили на сервере. */
    fun saveEditor(force: Boolean = false, then: (() -> Unit)? = null) {
        val st = editor ?: return
        val dav = a.dav() ?: return
        if (st.saving) return
        st.saving = true
        viewModelScope.launch {
            try {
                val text = st.value.text
                val bytes = TextCodec.encode(text, st.charset, st.bom, st.crlf)
                val newTag = withContext(Dispatchers.IO) {
                    dav.putBytes(st.entry.path, bytes, if (force) null else st.etag)
                        ?: dav.stat(st.entry.path)?.etag
                }
                st.etag = newTag
                st.raw = bytes
                st.savedText = text
                st.metaChanged = false
                st.conflict = false
                _message.value = "Сохранено"
                then?.invoke()
            } catch (e: HttpError) {
                if (e.code == 412) st.conflict = true else _message.value = e.message
            } catch (e: Exception) {
                _message.value = e.message ?: "Ошибка сохранения"
            } finally {
                st.saving = false
            }
        }
    }

    fun createTextFile(name: String) {
        val dav = a.dav() ?: return
        val p = joinPath(_path.value, name)
        viewModelScope.launch {
            try {
                val e = withContext(Dispatchers.IO) {
                    if (dav.stat(p) == null) dav.putBytes(p, ByteArray(0), null)
                    dav.stat(p)
                }
                if (e != null) openEditor(e)
                refresh()
            } catch (e: Exception) {
                _message.value = e.message ?: "Ошибка"
            }
        }
    }

    // ---------- Просмотр изображений ----------

    var viewer by mutableStateOf<ViewerState?>(null)
        private set

    fun openViewer(items: List<RemoteEntry>, start: Int) { viewer = ViewerState(items, start) }
    fun closeViewer() { viewer = null }

    fun deleteFromViewer(e: RemoteEntry) {
        val v = viewer ?: return
        io("Удалено") { it.delete(e.path) }
        val rest = v.items.filter { it.path != e.path }
        viewer = if (rest.isEmpty()) null
        else ViewerState(rest, v.items.indexOf(e).coerceAtMost(rest.size - 1).coerceAtLeast(0))
    }
}

class ViewerState(val items: List<RemoteEntry>, val start: Int)

/** Состояние открытого в редакторе файла. */
class EditorState(val entry: RemoteEntry) {
    var loading by mutableStateOf(true)
    var error by mutableStateOf<String?>(null)
    var value by mutableStateOf(TextFieldValue(""))
        private set
    var savedText by mutableStateOf("")
    var charset by mutableStateOf<Charset>(Charsets.UTF_8)
    var crlf by mutableStateOf(false)
    var readOnly by mutableStateOf(false)
    var looksBinary by mutableStateOf(false)
    var saving by mutableStateOf(false)
    var conflict by mutableStateOf(false)
    var raw: ByteArray = ByteArray(0)
    var bom: ByteArray = ByteArray(0)
    var etag: String? = null

    /** Изменены свойства файла (концы строк), а не текст. */
    var metaChanged by mutableStateOf(false)

    val dirty: Boolean get() = metaChanged || value.text != savedText

    private val undoStack = ArrayDeque<TextFieldValue>()
    private val redoStack = ArrayDeque<TextFieldValue>()
    private var lastPush = 0L
    var history by mutableIntStateOf(0)
        private set
    val canUndo: Boolean get() { history; return undoStack.isNotEmpty() }
    val canRedo: Boolean get() { history; return redoStack.isNotEmpty() }

    fun apply(d: TextCodec.Decoded) {
        charset = d.charset; bom = d.bom; crlf = d.crlf; looksBinary = d.looksBinary
        value = TextFieldValue(d.text)
        savedText = d.text
        metaChanged = false
        undoStack.clear(); redoStack.clear(); history++
    }

    fun onChange(v: TextFieldValue) {
        if (v.text != value.text) {
            val now = System.currentTimeMillis()
            if (undoStack.isEmpty() || now - lastPush > 700) {
                undoStack.addLast(value)
                if (undoStack.size > 300) undoStack.removeFirst()
            }
            lastPush = now
            redoStack.clear()
            history++
        }
        value = v
    }

    /** Программная замена текста (поиск/замена) с записью в историю. */
    fun set(v: TextFieldValue, record: Boolean = true) {
        if (record && v.text != value.text) {
            undoStack.addLast(value); redoStack.clear(); lastPush = 0; history++
        }
        value = v
    }

    fun undo() {
        val p = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(value); value = p; lastPush = 0; history++
    }

    fun redo() {
        val n = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(value); value = n; lastPush = 0; history++
    }

    companion object {
        /** До этого размера файл можно редактировать. */
        const val MAX_EDIT = 1L * 1024 * 1024
        /** До этого размера — только просмотр. */
        const val MAX_VIEW = 20L * 1024 * 1024
    }
}
