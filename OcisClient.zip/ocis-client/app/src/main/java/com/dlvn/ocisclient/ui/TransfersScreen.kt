package com.dlvn.ocisclient.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvn.ocisclient.transfer.TState
import com.dlvn.ocisclient.transfer.TaskUi
import com.dlvn.ocisclient.util.fmtSize

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransfersScreen(vm: MainViewModel, onBack: () -> Unit) {
    val tasks by vm.transfers.ui.collectAsState()
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Передачи") },
            navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
            actions = {
                IconButton({ vm.transfers.clearFinished() }) { Icon(Icons.Filled.ClearAll, "Очистить завершённые") }
            }
        )
    }) { pad ->
        if (tasks.isEmpty()) {
            Text("Передач нет", Modifier.padding(pad).padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tasks, key = { it.id }) { t -> TaskCard(t, vm) }
        }
    }
}

@Composable
private fun TaskCard(t: TaskUi, vm: MainViewModel) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(t.title, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleSmall)
                when (t.state) {
                    TState.RUNNING, TState.QUEUED ->
                        IconButton({ vm.transfers.cancel(t.id) }) { Icon(Icons.Filled.Close, "Отменить") }
                    TState.FAILED, TState.CANCELLED ->
                        IconButton({ vm.transfers.retry(t.id) }) { Icon(Icons.Filled.Refresh, "Повторить") }
                    TState.DONE -> {}
                }
            }
            val frac = if (t.total > 0) (t.done.toFloat() / t.total).coerceIn(0f, 1f) else 0f
            if (t.state == TState.RUNNING && t.total == 0L) LinearProgressIndicator(Modifier.fillMaxWidth())
            else LinearProgressIndicator(progress = { if (t.state == TState.DONE) 1f else frac }, modifier = Modifier.fillMaxWidth())

            val status = when (t.state) {
                TState.QUEUED -> "В очереди"
                TState.RUNNING -> "${t.phase} · ${fmtSize(t.speed)}/с"
                TState.DONE -> "Готово · в среднем ${fmtSize(t.avgSpeed)}/с"
                TState.FAILED -> "Ошибка: ${t.error}"
                TState.CANCELLED -> "Отменено"
            }
            Text(status, style = MaterialTheme.typography.bodySmall,
                color = if (t.state == TState.FAILED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp))
            val files = if (t.filesTotal > 1) " · файлов ${t.filesDone}/${t.filesTotal}" +
                (if (t.filesSkipped > 0) " (пропущено ${t.filesSkipped})" else "") else ""
            Text("${fmtSize(t.done)} из ${fmtSize(t.total)}$files",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
