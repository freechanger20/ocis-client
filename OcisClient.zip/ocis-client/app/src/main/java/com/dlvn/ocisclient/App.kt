package com.dlvn.ocisclient

import android.app.Application
import com.dlvn.ocisclient.data.Account
import com.dlvn.ocisclient.data.Prefs
import com.dlvn.ocisclient.net.WebDav
import com.dlvn.ocisclient.transfer.Ops
import com.dlvn.ocisclient.transfer.TransferManager

class App : Application() {
    lateinit var prefs: Prefs
        private set
    lateinit var transfers: TransferManager
        private set

    private var cachedDav: WebDav? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        transfers = TransferManager(this) { prefs.settings.value.parallelTasks }
    }

    @Synchronized
    fun dav(): WebDav? {
        val a: Account = prefs.account.value ?: return null
        val c = cachedDav
        if (c != null && c.account == a) return c
        return WebDav(a).also { cachedDav = it }
    }

    /** Операции с текущими настройками (настройки читаются в момент постановки задачи). */
    fun ops(): Ops? = dav()?.let { Ops(this, it, prefs.settings.value) }
}
