package com.dlvn.ocisclient

import android.app.Application
import android.os.Build
import coil.ImageLoader
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.dlvn.ocisclient.data.Account
import com.dlvn.ocisclient.data.Prefs
import com.dlvn.ocisclient.net.WebDav
import com.dlvn.ocisclient.transfer.Ops
import com.dlvn.ocisclient.transfer.TransferManager

class App : Application() {
    lateinit var prefs: Prefs
        private set
    lateinit var transfers: TransferManager
        private set

    private var cachedDav: WebDav? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        transfers = TransferManager(this) { prefs.settings.value.parallelTasks }
    }

    @Synchronized
    fun dav(): WebDav? {
        val a: Account = prefs.account.value ?: return null
        val c = cachedDav
        if (c != null && c.account == a) return c
        return WebDav(a).also { cachedDav = it }
    }

    private var cachedLoader: Pair<WebDav, ImageLoader>? = null

    /** Загрузчик картинок с авторизацией в облаке и дисковым кешем. */
    @Synchronized
    fun imageLoader(): ImageLoader? {
        val d = dav() ?: return null
        cachedLoader?.let { if (it.first === d) return it.second }
        val loader = ImageLoader.Builder(this)
            .okHttpClient(d.client)
            .components {
                if (Build.VERSION.SDK_INT >= 28) add(ImageDecoderDecoder.Factory()) else add(GifDecoder.Factory())
            }
            .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.25).build() }
            .diskCache {
                DiskCache.Builder().directory(cacheDir.resolve("images")).maxSizeBytes(300L * 1024 * 1024).build()
            }
            .respectCacheHeaders(false)
            .crossfade(true)
            .build()
        cachedLoader = d to loader
        return loader
    }

    /** Операции с текущими настройками (настройки читаются в момент постановки задачи). */
    fun ops(): Ops? = dav()?.let { Ops(this, it, prefs.settings.value) }
}
