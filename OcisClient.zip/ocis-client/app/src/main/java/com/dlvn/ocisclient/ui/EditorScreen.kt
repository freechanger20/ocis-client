package com.dlvn.ocisclient.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvn.ocisclient.util.TextCodec
import com.dlvn.ocisclient.util.fmtSize

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: MainViewModel, s: EditorState) {
    val st by vm.prefs.settings.collectAsState()
    val msg by vm.message.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(msg) { msg?.let { snackbar.showSnackbar(it); vm.consumeMessage() } }

    var askClose by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var replacing by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var replacement by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var csMenu by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }

    BackHandler {
        when {
            searching -> searching = false
            s.dirty -> askClose = true
            else -> vm.closeEditor()
        }
    }

    fun find(forward: Boolean) {
        if (query.isEmpty()) return
        val text = s.value.text
        val sel = s.value.selection
        var idx = if (forward) text.indexOf(query, sel.max, ignoreCase = true)
        else text.lastIndexOf(query, (sel.min - 1).coerceAtLeast(0), ignoreCase = true).takeIf { sel.min > 0 } ?: -1
        if (idx < 0) idx = if (forward) text.indexOf(query, 0, true) else text.lastIndexOf(query, text.length, true)
        if (idx < 0) { vm.toast("Не найдено"); return }
        s.set(s.value.copy(selection = TextRange(idx, idx + query.length)), record = false)
        runCatching { focus.requestFocus() }
    }

    fun replaceOne() {
        val v = s.value
        val selText = v.text.substring(v.selection.min, v.selection.max)
        if (query.isNotEmpty() && selText.equals(query, ignoreCase = true)) {
            val t = v.text.replaceRange(v.selection.min, v.selection.max, replacement)
            s.set(TextFieldValue(t, TextRange(v.selection.min + replacement.length)))
        }
        find(true)
    }

    fun replaceAll() {
        if (query.isEmpty()) return
        val n = Regex(Regex.escape(query), RegexOption.IGNORE_CASE).findAll(s.value.text).count()
        if (n == 0) { vm.toast("Не найдено"); return }
        s.set(TextFieldValue(s.value.text.replace(query, replacement, ignoreCase = true)))
        vm.toast("Заменено: $n")
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            (if (s.dirty) "• " else "") + s.entry.name,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            if (s.readOnly) "только просмотр" else s.entry.path.substringBeforeLast('/').ifEmpty { "/" },
                            style = MaterialTheme.typography.labelSmall, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton({ if (s.dirty) askClose = true else vm.closeEditor() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Закрыть")
                    }
                },
                actions = {
                    if (!s.readOnly) {
                        IconButton({ s.undo() }, enabled = s.canUndo) { Icon(Icons.AutoMirrored.Filled.Undo, "Отменить") }
                        IconButton({ s.redo() }, enabled = s.canRedo) { Icon(Icons.AutoMirrored.Filled.Redo, "Повторить") }
                    }
                    IconButton({ searching = !searching }) { Icon(Icons.Filled.Search, "Поиск") }
                    if (!s.readOnly) {
                        IconButton({ vm.saveEditor() }, enabled = s.dirty && !s.saving) {
                            if (s.saving) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                            else Icon(Icons.Filled.Save, "Сохранить")
                        }
                    }
                    Box {
                        IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "Ещё") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(
                                text = { Text("Перенос строк") },
                                trailingIcon = { if (st.editorWrap) Icon(Icons.Filled.Check, null) },
                                onClick = { vm.saveSettings(st.copy(editorWrap = !st.editorWrap)) })
                            DropdownMenuItem(
                                text = { Text("Моноширинный шрифт") },
                                trailingIcon = { if (st.editorMono) Icon(Icons.Filled.Check, null) },
                                onClick = { vm.saveSettings(st.copy(editorMono = !st.editorMono)) })
                            DropdownMenuItem(
                                text = { Text("Шрифт крупнее (${st.editorFont})") },
                                onClick = { vm.saveSettings(st.copy(editorFont = (st.editorFont + 1).coerceAtMost(32))) })
                            DropdownMenuItem(
                                text = { Text("Шрифт мельче") },
                                onClick = { vm.saveSettings(st.copy(editorFont = (st.editorFont - 1).coerceAtLeast(9))) })
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Кодировка: ${TextCodec.label(s.charset)}") },
                                onClick = { menu = false; csMenu = true })
                            DropdownMenuItem(
                                text = { Text("Концы строк: ${if (s.crlf) "Windows (CRLF)" else "Unix (LF)"}") },
                                onClick = { s.crlf = !s.crlf; s.metaChanged = true })
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Перечитать с сервера") },
                                onClick = { menu = false; vm.reloadEditor() })
                        }
                        DropdownMenu(csMenu, { csMenu = false }) {
                            if (s.dirty) DropdownMenuItem(
                                text = { Text("Сначала сохраните изменения", color = MaterialTheme.colorScheme.error) },
                                onClick = { csMenu = false }, enabled = false)
                            TextCodec.CHARSETS.forEach { cs ->
                                DropdownMenuItem(
                                    text = { Text(TextCodec.label(cs)) },
                                    trailingIcon = { if (cs == s.charset) Icon(Icons.Filled.Check, null) },
                                    enabled = !s.dirty,
                                    onClick = { csMenu = false; vm.changeCharset(cs) })
                            }
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (!s.loading && s.error == null) {
                val v = s.value
                val info = remember(v.text, v.selection) {
                    val pos = v.selection.start.coerceIn(0, v.text.length)
                    var line = 1; var lastNl = -1
                    for (i in 0 until pos) if (v.text[i] == '\n') { line++; lastNl = i }
                    val lines = v.text.count { it == '\n' } + 1
                    "Стр $line, кол ${pos - lastNl} · строк $lines · ${fmtSize(s.raw.size.toLong())}"
                }
                Surface(tonalElevation = 2.dp) {
                    Text(
                        "$info · ${TextCodec.label(s.charset)}${if (s.crlf) " · CRLF" else ""}",
                        Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = 12.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                    )
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (searching) {
                Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true,
                            placeholder = { Text("Найти") })
                        IconButton({ find(false) }) { Icon(Icons.Filled.KeyboardArrowUp, "Назад") }
                        IconButton({ find(true) }) { Icon(Icons.Filled.KeyboardArrowDown, "Вперёд") }
                        IconButton({ searching = false }) { Icon(Icons.Filled.Close, "Закрыть") }
                    }
                    if (!s.readOnly) {
                        if (replacing) Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(replacement, { replacement = it }, Modifier.weight(1f), singleLine = true,
                                placeholder = { Text("Заменить на") })
                            TextButton({ replaceOne() }) { Text("Заменить") }
                            TextButton({ replaceAll() }) { Text("Все") }
                        } else TextButton({ replacing = true }) { Text("Замена…") }
                    }
                }
            }
            if (s.looksBinary && !s.loading) {
                Text("Похоже, это не текстовый файл. Не сохраняйте его, если не уверены.",
                    Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            when {
                s.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                s.error != null -> Column(Modifier.padding(24.dp)) {
                    Text(s.error ?: "", color = MaterialTheme.colorScheme.error)
                    TextButton({ vm.reloadEditor() }) { Text("Повторить") }
                }
                else -> {
                    val style = TextStyle(
                        fontFamily = if (st.editorMono) FontFamily.Monospace else FontFamily.Default,
                        fontSize = st.editorFont.sp,
                        lineHeight = (st.editorFont * 1.4f).sp,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    if (s.readOnly) ReadOnlyText(s.value.text, style)
                    else EditorField(s, style, st.editorWrap, focus)
                }
            }
        }
    }

    if (askClose) AlertDialog(
        onDismissRequest = { askClose = false },
        title = { Text("Сохранить изменения?") },
        text = { Text(s.entry.name) },
        confirmButton = {
            TextButton({ askClose = false; vm.saveEditor { vm.closeEditor() } }) { Text("Сохранить") }
        },
        dismissButton = {
            Row {
                TextButton({ askClose = false; vm.closeEditor() }) { Text("Не сохранять") }
                TextButton({ askClose = false }) { Text("Отмена") }
            }
        }
    )

    if (s.conflict) AlertDialog(
        onDismissRequest = { s.conflict = false },
        title = { Text("Файл изменён на сервере") },
        text = { Text("Пока вы редактировали, файл изменили в облаке. Перезаписать его вашей версией?") },
        confirmButton = { TextButton({ s.conflict = false; vm.saveEditor(force = true) }) { Text("Перезаписать") } },
        dismissButton = { TextButton({ s.conflict = false }) { Text("Отмена") } }
    )
}

@Composable
private fun EditorField(s: EditorState, style: TextStyle, wrap: Boolean, focus: FocusRequester) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val minW = maxWidth
        val minH = maxHeight
        Box(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .then(if (wrap) Modifier else Modifier.horizontalScroll(rememberScrollState()))
        ) {
            BasicTextField(
                value = s.value,
                onValueChange = { s.onChange(it) },
                textStyle = style,
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None),
                modifier = Modifier
                    .then(if (wrap) Modifier.fillMaxWidth() else Modifier.widthIn(min = minW))
                    .heightIn(min = minH)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .focusRequester(focus),
            )
        }
    }
}

/** Большие файлы: построчный просмотр без загрузки всего текста в поле ввода. */
@Composable
private fun ReadOnlyText(text: String, style: TextStyle) {
    val lines = remember(text) { text.split('\n') }
    SelectionContainer {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            itemsIndexed(lines) { _, line -> Text(line, style = style) }
        }
    }
}
