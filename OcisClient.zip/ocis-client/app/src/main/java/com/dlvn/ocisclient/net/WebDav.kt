package com.dlvn.ocisclient.net

import android.util.Xml
import com.dlvn.ocisclient.data.Account
import okhttp3.ConnectionPool
import okhttp3.Credentials
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.xmlpull.v1.XmlPullParser
import java.io.IOException
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

data class RemoteEntry(
    val name: String,
    /** Путь относительно корня личного пространства, начинается с "/". */
    val path: String,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val etag: String?,
    val fileId: String?,
    val mime: String?,
)

class HttpError(val code: Int, message: String) : IOException(message)

class WebDav(val account: Account) {

    private val base: HttpUrl = account.server.trim().trimEnd('/').toHttpUrl()
    private val davRoot: HttpUrl = base.newBuilder()
        .addPathSegments("remote.php/dav/files")
        .addPathSegment(account.user)
        .build()

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        // HTTP/1.1: каждая параллельная передача идёт по своему TCP-соединению,
        // это даёт заметно больше скорости, чем мультиплексирование HTTP/2 в одном.
        .protocols(listOf(Protocol.HTTP_1_1))
        .connectionPool(ConnectionPool(16, 5, TimeUnit.MINUTES))
        .retryOnConnectionFailure(true)
        .addInterceptor { chain ->
            chain.proceed(
                chain.request().newBuilder()
                    .header("Authorization", Credentials.basic(account.user, account.token))
                    .header("User-Agent", "OcisClient-Android")
                    .build()
            )
        }
        .build()

    fun url(path: String): HttpUrl {
        val b = davRoot.newBuilder()
        path.split('/').filter { it.isNotEmpty() }.forEach { b.addPathSegment(it) }
        return b.build()
    }

    private fun check(r: Response, vararg ok: Int): Response {
        if (r.code in ok || (ok.isEmpty() && r.isSuccessful)) return r
        val msg = when (r.code) {
            401 -> "Неверный логин или токен (401)"
            403 -> "Доступ запрещён (403)"
            404 -> "Не найдено (404)"
            507 -> "На сервере закончилось место (507)"
            else -> "Ошибка сервера ${r.code}"
        }
        r.close()
        throw HttpError(r.code, msg)
    }

    // ---------- Список файлов ----------

    fun list(path: String, depth: String = "1"): List<RemoteEntry> {
        val body = PROPFIND_BODY.toRequestBody("application/xml; charset=utf-8".toMediaType())
        val req = Request.Builder().url(url(path)).method("PROPFIND", body)
            .header("Depth", depth).build()
        client.newCall(req).execute().use { r ->
            check(r, 207)
            val all = parse(r.body!!.byteStream())
            val self = normalize(path)
            return all.filter { normalize(it.path) != self }
        }
    }

    fun stat(path: String): RemoteEntry? = try {
        val body = PROPFIND_BODY.toRequestBody("application/xml; charset=utf-8".toMediaType())
        val req = Request.Builder().url(url(path)).method("PROPFIND", body).header("Depth", "0").build()
        client.newCall(req).execute().use { r ->
            if (r.code == 404) null else {
                check(r, 207); parse(r.body!!.byteStream()).firstOrNull()
            }
        }
    } catch (e: HttpError) {
        if (e.code == 404) null else throw e
    }

    /** Рекурсивный обход папки (по одному запросу на каждую подпапку). */
    fun walk(path: String, out: MutableList<RemoteEntry> = mutableListOf()): List<RemoteEntry> {
        for (e in list(path)) {
            out += e
            if (e.isDir) walk(e.path, out)
        }
        return out
    }

    private fun normalize(p: String) = "/" + p.split('/').filter { it.isNotEmpty() }.joinToString("/")

    private fun parse(input: InputStream): List<RemoteEntry> {
        val rootSegs = davRoot.pathSegments.filter { it.isNotEmpty() }.size
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
        p.setInput(input, "UTF-8")
        val res = ArrayList<RemoteEntry>()
        var href: String? = null
        var isDir = false
        var size = -1L
        var ocSize = -1L
        var modified = 0L
        var etag: String? = null
        var fileId: String? = null
        var mime: String? = null
        var text = StringBuilder()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> {
                    text = StringBuilder()
                    when (p.name) {
                        "response" -> {
                            href = null; isDir = false; size = -1; ocSize = -1; modified = 0
                            etag = null; fileId = null; mime = null
                        }
                        "collection" -> isDir = true
                    }
                }
                XmlPullParser.TEXT -> text.append(p.text)
                XmlPullParser.END_TAG -> {
                    val t = text.toString().trim()
                    when (p.name) {
                        "href" -> href = t
                        "getcontentlength" -> size = t.toLongOrNull() ?: -1
                        "size" -> ocSize = t.toLongOrNull() ?: -1
                        "getlastmodified" -> modified = parseDate(t)
                        "getetag" -> etag = t.trim('"')
                        "fileid" -> fileId = t
                        "getcontenttype" -> mime = t
                        "response" -> {
                            val h = href
                            if (h != null) {
                                val u = davRoot.resolve(h)
                                if (u != null) {
                                    val segs = u.pathSegments.filter { it.isNotEmpty() }.drop(rootSegs)
                                    val path = "/" + segs.joinToString("/")
                                    res += RemoteEntry(
                                        name = segs.lastOrNull() ?: "",
                                        path = path,
                                        isDir = isDir,
                                        size = if (size >= 0) size else maxOf(ocSize, 0),
                                        modified = modified,
                                        etag = etag,
                                        fileId = fileId,
                                        mime = mime,
                                    )
                                }
                            }
                        }
                    }
                    text = StringBuilder()
                }
            }
            ev = p.next()
        }
        return res
    }

    private fun parseDate(s: String): Long = try {
        SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US).parse(s)?.time ?: 0
    } catch (_: Exception) { 0 }

    // ---------- Операции ----------

    /** Создаёт папку. Возвращает true, если создана, false — если уже существует. */
    fun mkcol(path: String): Boolean {
        val req = Request.Builder().url(url(path)).method("MKCOL", null).build()
        client.newCall(req).execute().use { r ->
            if (r.code == 201) return true
            if (r.code == 405) return false // уже есть
            check(r, 201)
            return true
        }
    }

    fun delete(path: String) {
        val req = Request.Builder().url(url(path)).delete().build()
        client.newCall(req).execute().use { check(it, 204, 200) }
    }

    fun move(from: String, to: String) {
        val req = Request.Builder().url(url(from)).method("MOVE", null)
            .header("Destination", url(to).toString())
            .header("Overwrite", "F").build()
        client.newCall(req).execute().use { check(it, 201, 204) }
    }

    fun put(path: String, body: RequestBody, mtimeMs: Long?) {
        val b = Request.Builder().url(url(path)).put(body)
        if (mtimeMs != null && mtimeMs > 0) b.header("X-OC-Mtime", (mtimeMs / 1000).toString())
        client.newCall(b.build()).execute().use { check(it, 200, 201, 204) }
    }

    /** GET с необязательным диапазоном байт. Вызывающий обязан закрыть ответ. */
    fun get(path: String, from: Long = 0, toInclusive: Long = -1): Response {
        val b = Request.Builder().url(url(path)).get()
        if (from > 0 || toInclusive >= 0) {
            b.header("Range", "bytes=$from-" + if (toInclusive >= 0) toInclusive.toString() else "")
        }
        val r = client.newCall(b.build()).execute()
        return check(r, 200, 206)
    }

    /** Серверный архиватор oCIS: отдаёт папку одним потоком (zip или tar). */
    fun archive(fileId: String, format: String): Response {
        val u = base.newBuilder().addPathSegment("archiver")
            .addQueryParameter("id", fileId)
            .addQueryParameter("output-format", format)
            .build()
        val r = client.newCall(Request.Builder().url(u).get().build()).execute()
        if (!r.isSuccessful) {
            val txt = r.body?.string()?.take(300).orEmpty()
            r.close()
            throw HttpError(r.code, "Архиватор: ошибка ${r.code} $txt".trim())
        }
        return r
    }

    companion object {
        private const val PROPFIND_BODY = """<?xml version="1.0" encoding="utf-8"?>
<d:propfind xmlns:d="DAV:" xmlns:oc="http://owncloud.org/ns">
 <d:prop>
  <d:resourcetype/><d:getcontentlength/><d:getlastmodified/><d:getetag/>
  <d:getcontenttype/><oc:fileid/><oc:size/>
 </d:prop>
</d:propfind>"""
    }
}
