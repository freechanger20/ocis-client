package com.dlvn.ocisclient.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import com.dlvn.ocisclient.data.Settings
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.dlvn.ocisclient.util.Saf
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel, onPickFolder: () -> Unit, onBack: () -> Unit) {
    val s by vm.prefs.settings.collectAsState()
    val acc by vm.prefs.account.collectAsState()
    val ctx = LocalContext.current
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Настройки") },
            navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } }
        )
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            AppearanceSection(s) { vm.saveSettings(it) }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Скорость", style = MaterialTheme.typography.titleMedium)
            IntSlider("Файлов одновременно", s.parallelFiles, 1..8,
                "Сколько файлов папки передаётся параллельно") { vm.saveSettings(s.copy(parallelFiles = it)) }
            IntSlider("Потоков на один большой файл", s.segments, 1..8,
                "Файлы больше 8 МБ скачиваются частями параллельно") { vm.saveSettings(s.copy(segments = it)) }
            IntSlider("Задач одновременно", s.parallelTasks, 1..4,
                "Применяется после перезапуска приложения") { vm.saveSettings(s.copy(parallelTasks = it)) }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Архивация", style = MaterialTheme.typography.titleMedium)
            IntSlider("Уровень сжатия ZIP", s.zipLevel, 0..9,
                "0 — без сжатия (быстрее всего, для фото и видео), 1 — быстро, 9 — максимум") {
                vm.saveSettings(s.copy(zipLevel = it))
            }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Папка для скачивания", style = MaterialTheme.typography.titleMedium)
            val folderName = remember(s.downloadTree) {
                s.downloadTree?.let { runCatching { Saf.treeName(ctx, Uri.parse(it)) }.getOrNull() } ?: "Не выбрана"
            }
            Text(
                folderName,
                modifier = Modifier.padding(vertical = 6.dp)
            )
            OutlinedButton(onPickFolder) { Text("Выбрать папку") }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Аккаунт", style = MaterialTheme.typography.titleMedium)
            Text("${acc?.user} @ ${acc?.server}", modifier = Modifier.padding(vertical = 6.dp))
            OutlinedButton({ vm.logout(); onBack() }) { Text("Выйти") }
        }
    }
}

@Composable
private fun IntSlider(title: String, value: Int, range: IntRange, hint: String, onChange: (Int) -> Unit) {
    Column(Modifier.padding(top = 12.dp)) {
        Text("$title: $value")
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
            steps = range.last - range.first - 1,
        )
        if (hint.isNotEmpty()) Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Chips(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, t ->
            FilterChip(selected = i == selected, onClick = { onSelect(i) }, label = { Text(t) })
        }
    }
}

@Composable
private fun Swatches(selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
        PALETTE.forEachIndexed { i, (_, c) ->
            Box(
                Modifier.padding(end = 10.dp).size(36.dp).clip(CircleShape).background(c)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center
            ) { if (i == selected) Icon(Icons.Filled.Check, null, tint = Color.White) }
        }
    }
}

@Composable
private fun SwitchRow(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!value) }.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, Modifier.weight(1f))
        Switch(value, onChange)
    }
}

@Composable
private fun Label(t: String) = Text(t, Modifier.padding(top = 14.dp, bottom = 4.dp))

@Composable
private fun AppearanceSection(s: Settings, save: (Settings) -> Unit) {
    Text("Внешний вид", style = MaterialTheme.typography.titleMedium)

    // Предпросмотр с текущими настройками
    Card(Modifier.fillMaxWidth().padding(top = 10.dp)) {
        Column(Modifier.padding(vertical = 4.dp)) {
            listOf(
                Triple("Документы", true, "12 файлов"),
                Triple("Фото_отпуск.jpg", false, "3,2 МБ · 17.11.2026"),
                Triple("Отчёт.pdf", false, "540 КБ · 16.11.2026"),
            ).forEach { (name, dir, info) ->
                val kind = kindOf(name, dir)
                val tint = when {
                    dir -> paletteColor(s.folderColor)
                    s.coloredIcons -> kind.color
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
                val compact = s.viewMode == 1
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = (if (compact) s.rowSpacing / 2 else s.rowSpacing).dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(iconFor(kind, s.iconStyle), null,
                        Modifier.size((if (compact) s.iconSize * 0.7f else s.iconSize.toFloat()).dp), tint = tint)
                    Column(Modifier.padding(start = 14.dp)) {
                        Text(name, maxLines = 1)
                        if (s.showDetails && !compact) Text(info, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    Label("Тема")
    Chips(THEMES, s.theme) { save(s.copy(theme = it)) }

    Label("Акцентный цвет")
    Swatches(s.accent) { save(s.copy(accent = it)) }

    Label("Вид файлов")
    Chips(VIEW_MODES, s.viewMode) { save(s.copy(viewMode = it)) }
    if (s.viewMode == 2) {
        IntSlider("Колонок в плитке", s.gridColumns, 2..6, "") { save(s.copy(gridColumns = it)) }
    }

    Column(Modifier.padding(top = 12.dp)) {
        Text("Размер шрифта: ${(s.fontScale * 100).roundToInt()}%")
        Slider(
            value = s.fontScale,
            onValueChange = { save(s.copy(fontScale = (it * 20).roundToInt() / 20f)) },
            valueRange = 0.8f..1.5f,
            steps = 13,
        )
    }
    IntSlider("Расстояние между строками", s.rowSpacing, 0..24, "") { save(s.copy(rowSpacing = it)) }
    IntSlider("Размер иконок", s.iconSize, 20..64, "") { save(s.copy(iconSize = it)) }

    Label("Стиль иконок")
    Chips(ICON_STYLES, s.iconStyle) { save(s.copy(iconStyle = it)) }

    Label("Цвет папок")
    Swatches(s.folderColor) { save(s.copy(folderColor = it)) }
    Text("Цвет отдельной папки: меню ⋮ у папки → «Цвет папки»",
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

    SwitchRow("Цветные иконки по типу файла", s.coloredIcons) { save(s.copy(coloredIcons = it)) }
    SwitchRow("Показывать размер и дату", s.showDetails) { save(s.copy(showDetails = it)) }
    SwitchRow("Разделители между строками", s.dividers) { save(s.copy(dividers = it)) }

    TextButton({
        val d = Settings()
        save(s.copy(
            theme = d.theme, accent = d.accent, viewMode = d.viewMode, fontScale = d.fontScale,
            rowSpacing = d.rowSpacing, iconSize = d.iconSize, iconStyle = d.iconStyle,
            coloredIcons = d.coloredIcons, folderColor = d.folderColor, showDetails = d.showDetails,
            gridColumns = d.gridColumns, dividers = d.dividers,
        ))
    }) { Text("Сбросить внешний вид") }
}
