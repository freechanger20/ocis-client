package com.dlvn.ocisclient.ui

import android.net.Uri
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.dlvn.ocisclient.util.Saf
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel, onPickFolder: () -> Unit, onBack: () -> Unit) {
    val s by vm.prefs.settings.collectAsState()
    val acc by vm.prefs.account.collectAsState()
    val ctx = LocalContext.current
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Настройки") },
            navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } }
        )
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("Скорость", style = MaterialTheme.typography.titleMedium)
            IntSlider("Файлов одновременно", s.parallelFiles, 1..8,
                "Сколько файлов папки передаётся параллельно") { vm.saveSettings(s.copy(parallelFiles = it)) }
            IntSlider("Потоков на один большой файл", s.segments, 1..8,
                "Файлы больше 8 МБ скачиваются частями параллельно") { vm.saveSettings(s.copy(segments = it)) }
            IntSlider("Задач одновременно", s.parallelTasks, 1..4,
                "Применяется после перезапуска приложения") { vm.saveSettings(s.copy(parallelTasks = it)) }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Архивация", style = MaterialTheme.typography.titleMedium)
            IntSlider("Уровень сжатия ZIP", s.zipLevel, 0..9,
                "0 — без сжатия (быстрее всего, для фото и видео), 1 — быстро, 9 — максимум") {
                vm.saveSettings(s.copy(zipLevel = it))
            }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Папка для скачивания", style = MaterialTheme.typography.titleMedium)
            val folderName = remember(s.downloadTree) {
                s.downloadTree?.let { runCatching { Saf.treeName(ctx, Uri.parse(it)) }.getOrNull() } ?: "Не выбрана"
            }
            Text(
                folderName,
                modifier = Modifier.padding(vertical = 6.dp)
            )
            OutlinedButton(onPickFolder) { Text("Выбрать папку") }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Аккаунт", style = MaterialTheme.typography.titleMedium)
            Text("${acc?.user} @ ${acc?.server}", modifier = Modifier.padding(vertical = 6.dp))
            OutlinedButton({ vm.logout(); onBack() }) { Text("Выйти") }
        }
    }
}

@Composable
private fun IntSlider(title: String, value: Int, range: IntRange, hint: String, onChange: (Int) -> Unit) {
    Column(Modifier.padding(top = 12.dp)) {
        Text("$title: $value")
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
            steps = range.last - range.first - 1,
        )
        Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
