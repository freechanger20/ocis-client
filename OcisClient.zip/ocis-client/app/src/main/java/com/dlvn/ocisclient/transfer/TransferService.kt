package com.dlvn.ocisclient.transfer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.dlvn.ocisclient.App
import com.dlvn.ocisclient.ui.MainActivity
import com.dlvn.ocisclient.util.fmtSize
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/** Держит передачи живыми, когда приложение свёрнуто, и показывает прогресс в шторке. */
class TransferService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watcher: Job? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Передача файлов", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, NOTIF_ID, build("Подготовка…", 0, 0), type)
        acquireLocks()
        if (watcher == null) {
            val mgr = (application as App).transfers
            watcher = scope.launch {
                mgr.ui.collectLatest { list ->
                    val active = list.filter { it.state == TState.RUNNING || it.state == TState.QUEUED }
                    if (active.isEmpty() && !mgr.hasActive()) {
                        val failed = list.count { it.state == TState.FAILED }
                        showFinal(if (failed > 0) "Завершено, ошибок: $failed" else "Все передачи завершены")
                        stopSelfClean()
                        return@collectLatest
                    }
                    val total = active.sumOf { it.total }
                    val done = active.sumOf { it.done }
                    val speed = active.sumOf { it.speed }
                    val pct = if (total > 0) (done * 100 / total).toInt() else 0
                    val text = "${active.size} задач · ${fmtSize(done)} из ${fmtSize(total)} · ${fmtSize(speed)}/с"
                    getSystemService(NotificationManager::class.java).notify(NOTIF_ID, build(text, pct, 100))
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun build(text: String, progress: Int, max: Int): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).putExtra("openTransfers", true),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Передача файлов")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentIntent(pi)
            .setProgress(max, progress, max == 0)
            .build()
    }

    private fun showFinal(text: String) {
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentTitle("oCIS Облако")
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 1, Intent(this, MainActivity::class.java).putExtra("openTransfers", true),
                    PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()
        getSystemService(NotificationManager::class.java).notify(NOTIF_DONE, n)
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        if (wake == null) {
            wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ocis:transfer").apply { acquire(6 * 3600_000L) }
        }
        if (wifi == null) {
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                .createWifiLock(mode, "ocis:transfer").apply { acquire() }
        }
    }

    private fun stopSelfClean() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        scope.cancel()
        wake?.takeIf { it.isHeld }?.release()
        wifi?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "transfers"
        private const val NOTIF_ID = 1
        private const val NOTIF_DONE = 2
    }
}
